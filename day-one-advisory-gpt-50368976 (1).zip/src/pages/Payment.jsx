import React, { useState, useEffect } from 'react';
import { Subscription } from '@/api/entities';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, ArrowLeft } from 'lucide-react';
import { createPageUrl } from "@/utils";
import { useNavigate } from 'react-router-dom';
// Remove Stripe imports that aren't available
// import { loadStripe } from '@stripe/stripe-js';
// import { Elements } from '@stripe/react-stripe-js';
// import StripeCheckoutForm from '../components/payments/StripeCheckoutForm';

// Remove Stripe promise
// const stripePromise = loadStripe('pk_test_51R6WufFQz823ctwsaE7M6yZlkCBG3J9GgqKXkP9kSosUTOwQlOy34zEVnNYnHZ8c8ua5X3MQVOoomkPWOzVjqETM00tIJBtYKX');

export default function Payment() {
  const [plan, setPlan] = useState(null);
  const [planDetails, setPlanDetails] = useState(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    companyName: '',
    cardNumber: '',
    expiryDate: '',
    cvc: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    // Get plan from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const selectedPlan = urlParams.get('plan');
    
    if (!selectedPlan) {
      navigate(createPageUrl('Subscribe'));
      return;
    }
    
    setPlan(selectedPlan);
    
    // Set plan details based on selection
    if (selectedPlan === 'monthly') {
      setPlanDetails({
        name: "Monthly Plan",
        price: 8,
        period: 'month',
        maxGpts: 50
      });
    } else if (selectedPlan === 'yearly') {
      setPlanDetails({
        name: "Yearly Plan",
        price: 50,
        period: 'year',
        maxGpts: 'unlimited'
      });
    } else {
      navigate(createPageUrl('Subscribe'));
    }
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Create subscription in database
      const subscriptionData = {
        tenant_id: crypto.randomUUID(),
        plan_id: plan === 'monthly' ? 'monthly_standard' : 'yearly_standard',
        billing_email: formData.email,
        company_name: formData.companyName,
        payment_method: {
          type: 'credit_card',
          last_four: formData.cardNumber.slice(-4) || '4242',
          expiry: formData.expiryDate || '12/25'
        },
        status: 'active',
        subscription_start: new Date().toISOString(),
        subscription_end: new Date(Date.now() + (plan === 'monthly' ? 30 : 365) * 24 * 60 * 60 * 1000).toISOString(),
        trial_ends_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 1-day trial
        features: {
          max_gpts: plan === 'monthly' ? 50 : 999999,
          max_users: plan === 'monthly' ? 10 : 20,
          max_storage_gb: plan === 'monthly' ? 20 : 50,
          support_level: plan === 'monthly' ? 'basic' : 'priority'
        }
      };

      await Subscription.create(subscriptionData);
      navigate(createPageUrl('UseGPT'));
    } catch (error) {
      console.error('Subscription error:', error);
      setError(error.message || 'Failed to process subscription. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!planDetails) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6 flex items-center text-gray-600 hover:text-gray-900"
          onClick={() => navigate(createPageUrl('Subscribe'))}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Plans
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Complete Your Purchase</CardTitle>
            <CardDescription>
              You've selected the {planDetails.name}: ${planDetails.price}/{planDetails.period}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6 p-4 bg-indigo-50 rounded-lg">
              <h3 className="font-medium text-indigo-900 mb-2">Plan Summary</h3>
              <ul className="space-y-1 text-sm text-indigo-700">
                <li className="flex justify-between">
                  <span>Price:</span>
                  <span>${planDetails.price}/{planDetails.period}</span>
                </li>
                <li className="flex justify-between">
                  <span>Max GPTs:</span>
                  <span>{planDetails.maxGpts}</span>
                </li>
                <li className="flex justify-between">
                  <span>Trial Period:</span>
                  <span>1 day</span>
                </li>
              </ul>
            </div>
            
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600">
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Jane Doe"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-2 border"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="jane@example.com"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-2 border"
                  />
                </div>
                
                <div>
                  <label htmlFor="companyName" className="block text-sm font-medium text-gray-700">Company Name</label>
                  <input
                    id="companyName"
                    name="companyName"
                    type="text"
                    required
                    value={formData.companyName}
                    onChange={handleInputChange}
                    placeholder="Acme Inc."
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-2 border"
                  />
                </div>
                
                <div>
                  <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700">Card Number</label>
                  <input
                    id="cardNumber"
                    name="cardNumber"
                    type="text"
                    required
                    value={formData.cardNumber}
                    onChange={handleInputChange}
                    placeholder="4242 4242 4242 4242"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-2 border"
                  />
                </div>
                
                <div className="flex space-x-4">
                  <div className="w-1/2">
                    <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700">Expiration Date</label>
                    <input
                      id="expiryDate"
                      name="expiryDate"
                      type="text"
                      required
                      value={formData.expiryDate}
                      onChange={handleInputChange}
                      placeholder="MM/YY"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-2 border"
                    />
                  </div>
                  <div className="w-1/2">
                    <label htmlFor="cvc" className="block text-sm font-medium text-gray-700">CVC</label>
                    <input
                      id="cvc"
                      name="cvc"
                      type="text"
                      required
                      value={formData.cvc}
                      onChange={handleInputChange}
                      placeholder="123"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-2 border"
                    />
                  </div>
                </div>
              </div>
              
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-indigo-600 hover:bg-indigo-700"
              >
                {isLoading ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-b-2 border-white" />
                    Processing...
                  </>
                ) : (
                  `Subscribe - $${planDetails.price}/${planDetails.period}`
                )}
              </Button>
              <p className="text-xs text-gray-500 text-center">
                This is a simulated checkout. In a real app, this would process through Stripe.
              </p>
            </form>
          </CardContent>
          <CardFooter className="text-sm text-gray-500 text-center">
            <div className="flex items-center justify-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-500" />
              <span>1-day free trial, then ${planDetails.price}/{planDetails.period}</span>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}