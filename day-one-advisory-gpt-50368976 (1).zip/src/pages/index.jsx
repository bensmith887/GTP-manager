import Layout from "./Layout.jsx";

import ManageGPTs from "./ManageGPTs";

import UseGPT from "./UseGPT";

import App from "./App";

import SharedGPT from "./SharedGPT";

import ManageShares from "./ManageShares";

import ManageUserAccess from "./ManageUserAccess";

import DocumentSources from "./DocumentSources";

import Documents from "./Documents";

import Subscribe from "./Subscribe";

import AdminDashboard from "./AdminDashboard";

import Payment from "./Payment";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    ManageGPTs: ManageGPTs,
    
    UseGPT: UseGPT,
    
    App: App,
    
    SharedGPT: SharedGPT,
    
    ManageShares: ManageShares,
    
    ManageUserAccess: ManageUserAccess,
    
    DocumentSources: DocumentSources,
    
    Documents: Documents,
    
    Subscribe: Subscribe,
    
    AdminDashboard: AdminDashboard,
    
    Payment: Payment,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<ManageGPTs />} />
                
                
                <Route path="/ManageGPTs" element={<ManageGPTs />} />
                
                <Route path="/UseGPT" element={<UseGPT />} />
                
                <Route path="/App" element={<App />} />
                
                <Route path="/SharedGPT" element={<SharedGPT />} />
                
                <Route path="/ManageShares" element={<ManageShares />} />
                
                <Route path="/ManageUserAccess" element={<ManageUserAccess />} />
                
                <Route path="/DocumentSources" element={<DocumentSources />} />
                
                <Route path="/Documents" element={<Documents />} />
                
                <Route path="/Subscribe" element={<Subscribe />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/Payment" element={<Payment />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}