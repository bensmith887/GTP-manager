import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";

export default function Subscribe() {
  const navigate = useNavigate();

  const plans = {
    monthly: {
      price: 8,
      period: 'month',
      features: [
        "50 GPTs",
        "User Management",
        "API Access",
        "Email Support",
        "Regular Updates"
      ]
    },
    yearly: {
      price: 50,
      period: 'year',
      features: [
        "Unlimited GPTs",
        "User Management",
        "API Access",
        "Priority Support",
        "Regular Updates"
      ]
    }
  };

  const getAnnualSavings = () => {
    const monthlyTotal = plans.monthly.price * 12;
    const yearlyTotal = plans.yearly.price;
    const savings = ((monthlyTotal - yearlyTotal) / monthlyTotal * 100).toFixed(0);
    return savings;
  };

  const handleSelectPlan = (plan) => {
    const queryParams = new URLSearchParams({ plan }).toString();
    navigate(createPageUrl('Payment') + '?' + queryParams);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            Choose Your Plan
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Get started with our flexible pricing plans. Includes a 1-day free trial.
          </p>
        </div>

        <div className="mt-12 grid md:grid-cols-2 gap-8 max-w-7xl mx-auto">
          {/* Monthly Plan Card */}
          <Card className="relative overflow-hidden transition-all duration-200 hover:scale-105">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">Monthly Plan</CardTitle>
              <CardDescription>Perfect for getting started</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">${plans.monthly.price}</span>
                <span className="text-gray-500">/month</span>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {plans.monthly.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 shrink-0" />
                    <span className="ml-3 text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={() => handleSelectPlan('monthly')}
                className="w-full bg-indigo-600 hover:bg-indigo-700"
              >
                Select Monthly Plan
              </Button>
            </CardFooter>
          </Card>

          {/* Yearly Plan Card */}
          <Card className="relative overflow-hidden transition-all duration-200 hover:scale-105">
            <div className="absolute top-0 right-0 bg-green-500 text-white px-3 py-1 rounded-bl-lg text-sm font-medium">
              Save {getAnnualSavings()}%
            </div>
            <CardHeader>
              <CardTitle className="text-2xl font-bold">Yearly Plan</CardTitle>
              <CardDescription>Best value for long-term use</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">${plans.yearly.price}</span>
                <span className="text-gray-500">/year</span>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {plans.yearly.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 shrink-0" />
                    <span className="ml-3 text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={() => handleSelectPlan('yearly')}
                className="w-full bg-indigo-600 hover:bg-indigo-700"
              >
                Select Yearly Plan
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}