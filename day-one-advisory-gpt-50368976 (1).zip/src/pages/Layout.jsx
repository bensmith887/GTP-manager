
import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import { User } from "@/api/entities";
import { Subscription } from "@/api/entities";
import { useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Pages that don't require subscription
  const publicPages = ['Subscribe', 'Payment', 'SharedGPT'];
  
  // Check if this is a public page
  const isPublicPage = publicPages.includes(currentPageName);
  
  useEffect(() => {
    checkSubscription();
  }, [currentPageName]);

  const checkSubscription = async () => {
    if (isPublicPage) {
      setLoading(false);
      return;
    }

    try {
      const user = await User.me();
      
      // For super admin, bypass subscription check
      if (user.role === 'super_admin') {
        setLoading(false);
        return;
      }

      const subs = await Subscription.list();
      const activeSub = subs.find(s => 
        ['active', 'trialing'].includes(s.status)
      );

      setSubscriptionStatus(activeSub ? activeSub.status : 'inactive');

      // Redirect to subscribe page if no active subscription
      if (!activeSub && currentPageName !== 'Subscribe') {
        navigate(createPageUrl('Subscribe'));
      }
    } catch (error) {
      console.error("Error checking subscription:", error);
      setSubscriptionStatus('error');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
    </div>;
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-50 to-gray-100">
      {!isPublicPage && <Header />}
      
      {subscriptionStatus === 'trialing' && (
        <div className="bg-yellow-50 border-b border-yellow-100">
          <div className="max-w-7xl mx-auto py-2 px-4">
            <Alert variant="warning" className="border-none bg-transparent">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Trial Period</AlertTitle>
              <AlertDescription>
                You're currently in trial mode. 
                <Button 
                  variant="link" 
                  className="px-2 text-yellow-800 underline"
                  onClick={() => navigate(createPageUrl('Subscribe'))}
                >
                  Upgrade now
                </Button>
                to ensure uninterrupted access.
              </AlertDescription>
            </Alert>
          </div>
        </div>
      )}

      <main className={`flex-1 container mx-auto px-4 py-6 md:py-8 pb-24 overflow-auto ${isPublicPage ? 'pt-12' : ''}`}>
        {children}
      </main>
      
      {isPublicPage && (
        <footer className="bg-white border-t py-4">
          <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
            Powered by Day One GPT Manager
          </div>
        </footer>
      )}
    </div>
  );
}
