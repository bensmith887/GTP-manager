import React, { useState, useEffect } from "react";
import { GPT } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import GPTForm from "../components/gpts/GPTForm";
import GPTList from "../components/gpts/GPTList";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { GPTStorageUtils } from "../components/gpts/GPTStorageUtils";

export default function ManageGPTs() {
  const [gpts, setGpts] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [gptToDelete, setGptToDelete] = useState(null);
  const [editingGpt, setEditingGpt] = useState(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    loadGPTs();
  }, []);

  const loadGPTs = async () => {
    const data = await GPT.list();
    setGpts(data);
  };

  const handleSubmit = async (formData) => {
    try {
      if (editingGpt) {
        await GPT.update(editingGpt.id, {
          name: formData.name,
          description: formData.description,
          system_prompt: formData.system_prompt,
          category: formData.category,
          is_active: formData.is_active,
          knowledge_base: formData.knowledge_base
        });
      } else {
        await GPT.create(formData);
      }
      setIsOpen(false);
      resetForm();
      loadGPTs();
      
      // Simple alert instead of toast
      alert(editingGpt ? "GPT updated successfully!" : "GPT created successfully!");
    } catch (error) {
      console.error("Error saving GPT:", error);
      alert("Error: " + (error.message || "Failed to save GPT"));
    }
  };

  const resetForm = () => {
    setEditingGpt(null);
  };

  const handleEdit = (gpt) => {
    setEditingGpt(gpt);
    setIsOpen(true);
  };

  const handleDelete = async () => {
    if (gptToDelete) {
      try {
        await GPT.delete(gptToDelete.id);
        setGptToDelete(null);
        setIsDeleteDialogOpen(false);
        loadGPTs();
        alert("GPT deleted successfully!");
      } catch (error) {
        console.error("Error deleting GPT:", error);
        alert("Error: " + (error.message || "Failed to delete GPT"));
      }
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">GPT Management</h1>
          <p className="text-gray-500">Create and manage your custom GPTs</p>
        </div>
        <div className="flex flex-col gap-3 items-end">
          <div className="flex gap-3">
            <Button 
              variant="outline"
              onClick={() => navigate(createPageUrl("UseGPT"))}
            >
              View GPTs
            </Button>
            <Button onClick={() => setIsOpen(true)} className="bg-indigo-600 hover:bg-indigo-700">
              <Plus className="w-4 h-4 mr-2" />
              New GPT
            </Button>
          </div>
          <GPTStorageUtils refreshGPTs={loadGPTs} />
        </div>
      </div>

      <GPTList 
        gpts={gpts}
        onEdit={handleEdit}
        onDelete={(gpt) => {
          setGptToDelete(gpt);
          setIsDeleteDialogOpen(true);
        }}
      />

      <Dialog open={isOpen} onOpenChange={(open) => {
        if (!open) resetForm();
        setIsOpen(open);
      }}>
        <DialogContent className="sm:max-w-[800px] h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingGpt ? "Edit GPT" : "Create New GPT"}</DialogTitle>
          </DialogHeader>
          <GPTForm
            gpt={editingGpt}
            onSubmit={handleSubmit}
            onCancel={() => {
              resetForm();
              setIsOpen(false);
            }}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the GPT
              configuration.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setGptToDelete(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}