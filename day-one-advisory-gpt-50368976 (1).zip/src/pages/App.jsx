import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ManagementPage from './ManagementPage';
import UserInterfacePage from './UserInterfacePage';

function App() {
  const [gpts, setGpts] = useState([]);
  
  // Load GPTs from localStorage on initial render
  useEffect(() => {
    const savedGpts = localStorage.getItem('gpts');
    if (savedGpts) {
      setGpts(JSON.parse(savedGpts));
    }
  }, []);
  
  // Save GPTs to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('gpts', JSON.stringify(gpts));
  }, [gpts]);
  
  // Add a new GPT configuration
  const addGpt = (newGpt) => {
    setGpts([...gpts, { ...newGpt, id: Date.now(), locked: false }]);
  };
  
  // Update an existing GPT configuration
  const updateGpt = (id, updatedGpt) => {
    setGpts(gpts.map(gpt => gpt.id === id ? { ...updatedGpt, id } : gpt));
  };
  
  // Toggle the locked status of a GPT
  const toggleLock = (id) => {
    setGpts(gpts.map(gpt => 
      gpt.id === id ? { ...gpt, locked: !gpt.locked } : gpt
    ));
  };
  
  // Delete a GPT configuration
  const deleteGpt = (id) => {
    setGpts(gpts.filter(gpt => gpt.id !== id));
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route 
            path="/" 
            element={
              <ManagementPage 
                gpts={gpts} 
                addGpt={addGpt}
                updateGpt={updateGpt}
                toggleLock={toggleLock}
                deleteGpt={deleteGpt}
              />
            } 
          />
          <Route 
            path="/use" 
            element={<UserInterfacePage gpts={gpts.filter(gpt => !gpt.locked)} />} 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;