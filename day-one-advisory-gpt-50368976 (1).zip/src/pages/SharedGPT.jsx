import React, { useState, useEffect } from "react";
import { GPT } from "@/api/entities";
import { GPTShare } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Wand2 } from "lucide-react";
import { format } from "date-fns";

export default function SharedGPT() {
  const [gpt, setGpt] = useState(null);
  const [shareInfo, setShareInfo] = useState(null);
  const [variables, setVariables] = useState({});
  const [output, setOutput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [isExpired, setIsExpired] = useState(false);
  const [isInvalid, setIsInvalid] = useState(false);

  useEffect(() => {
    loadSharedGPT();
  }, []);

  useEffect(() => {
    if (gpt) {
      // Extract all variables
      const variableMatches = gpt.system_prompt.match(/\{\{([^}]+)\}\}/g) || [];
      const uniqueVariables = [...new Set(variableMatches)].reduce((acc, variable) => {
        const cleanVar = variable.replace(/[{}]/g, "").trim();
        acc[cleanVar] = "";
        return acc;
      }, {});
      
      setVariables(uniqueVariables);
      setOutput("");
      setError("");
    }
  }, [gpt]);

  const loadSharedGPT = async () => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const shareCode = urlParams.get("code");
      
      if (!shareCode) {
        setIsInvalid(true);
        return;
      }
      
      const shareResults = await GPTShare.filter({ share_code: shareCode });
      
      if (!shareResults.length || !shareResults[0].is_active) {
        setIsInvalid(true);
        return;
      }
      
      const share = shareResults[0];
      setShareInfo(share);
      
      // Check if share has expired
      if (share.expiry_date) {
        const expiryDate = new Date(share.expiry_date);
        if (expiryDate < new Date()) {
          setIsExpired(true);
          return;
        }
      }
      
      // Load the GPT
      const gptData = await GPT.get(share.gpt_id);
      if (!gptData || !gptData.is_active) {
        setIsInvalid(true);
        return;
      }
      
      setGpt(gptData);
    } catch (error) {
      console.error("Error loading shared GPT:", error);
      setIsInvalid(true);
    }
  };

  const handleInputChange = (variable, value) => {
    setVariables(prev => ({
      ...prev,
      [variable]: value
    }));
  };

  const generateResponse = async () => {
    setIsLoading(true);
    setError("");
    
    try {
      let finalPrompt = gpt.system_prompt;
      
      // Replace all variables in the prompt
      Object.entries(variables).forEach(([key, value]) => {
        finalPrompt = finalPrompt.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
      });

      // If knowledge base exists and no user context was provided, use the knowledge base
      if (gpt.knowledge_base && (!variables.context || variables.context.trim() === "")) {
        finalPrompt = finalPrompt.replace(/\{\{context\}\}/g, gpt.knowledge_base);
      }

      const response = await InvokeLLM({
        prompt: finalPrompt
      });

      setOutput(response);
    } catch (error) {
      setError("Failed to generate response. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const categoryColors = {
    business: "bg-blue-100 text-blue-800",
    creative: "bg-purple-100 text-purple-800",
    technical: "bg-green-100 text-green-800",
    academic: "bg-yellow-100 text-yellow-800",
    personal: "bg-pink-100 text-pink-800"
  };

  if (isInvalid) {
    return (
      <Card className="max-w-lg mx-auto mt-12 border-red-200">
        <CardHeader>
          <div className="flex items-center gap-2 text-red-600">
            <AlertCircle className="w-5 h-5" />
            <CardTitle>Invalid Access Link</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p>This GPT access link is invalid or has been deactivated.</p>
          <p className="mt-2 text-sm text-gray-500">
            Please contact the person who shared this GPT with you for a new link.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (isExpired) {
    return (
      <Card className="max-w-lg mx-auto mt-12 border-amber-200">
        <CardHeader>
          <div className="flex items-center gap-2 text-amber-600">
            <AlertCircle className="w-5 h-5" />
            <CardTitle>Access Expired</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p>Your access to this GPT has expired.</p>
          <p className="mt-2 text-sm text-gray-500">
            Please contact the person who shared this GPT with you for extended access.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-8 pb-20 max-w-4xl mx-auto">
      {gpt ? (
        <>
          <Card className="border-none shadow-lg bg-white/80 backdrop-blur">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CardTitle className="text-2xl text-gray-900">{gpt.name}</CardTitle>
                <Badge className={categoryColors[gpt.category]}>
                  {gpt.category}
                </Badge>
              </div>
              {gpt.description && (
                <CardDescription className="text-gray-600 mt-2">
                  {gpt.description}
                </CardDescription>
              )}
            </CardHeader>
            {shareInfo?.expiry_date && (
              <CardFooter className="pt-0 pb-4">
                <p className="text-xs text-amber-600">
                  Access expires on {format(new Date(shareInfo.expiry_date), 'PPP')}
                </p>
              </CardFooter>
            )}
          </Card>

          <Card className="border-none shadow-lg bg-white/80 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900">Input Variables</CardTitle>
              <CardDescription className="text-gray-600">
                Fill in the required information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {Object.keys(variables).map((variable) => (
                <div key={variable} className="space-y-2">
                  <Label 
                    htmlFor={variable}
                    className="text-sm font-medium text-gray-700"
                  >
                    {variable.split('_').map(word => 
                      word.charAt(0).toUpperCase() + word.slice(1)
                    ).join(' ')}
                  </Label>
                  {variable.includes('message') || variable.includes('description') || variable === 'context' ? (
                    <Textarea
                      id={variable}
                      value={variables[variable]}
                      onChange={(e) => handleInputChange(variable, e.target.value)}
                      placeholder={`Enter ${variable.replace(/_/g, ' ')}...`}
                      className="h-24 transition-all duration-200 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1"
                    />
                  ) : (
                    <Input
                      id={variable}
                      value={variables[variable]}
                      onChange={(e) => handleInputChange(variable, e.target.value)}
                      placeholder={`Enter ${variable.replace(/_/g, ' ')}...`}
                      className="transition-all duration-200 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1"
                    />
                  )}
                </div>
              ))}
              <Button
                className="w-full bg-indigo-600 hover:bg-indigo-700 transition-all duration-200 shadow-sm hover:shadow mt-4"
                onClick={generateResponse}
                disabled={isLoading || Object.values(variables).some(v => !v.trim())}
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Generate Response
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {(output || error) && (
            <Card className="border-none shadow-lg bg-white/80 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">Generated Response</CardTitle>
              </CardHeader>
              <CardContent>
                {error ? (
                  <div className="text-red-500 p-4 bg-red-50 rounded-lg">
                    {error}
                  </div>
                ) : (
                  <div className="prose max-w-none">
                    <div className="whitespace-pre-wrap p-4 bg-gray-50 rounded-lg">
                      {output}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
        </div>
      )}
    </div>
  );
}