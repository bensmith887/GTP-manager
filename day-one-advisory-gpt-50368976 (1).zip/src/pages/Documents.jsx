
import React, { useState, useEffect } from 'react';
import { Document } from '@/api/entities';
import { DocumentSource } from '@/api/entities';
import { DocumentPermission } from '@/api/entities';
import { GPT } from '@/api/entities';
import { InvokeLLM } from "@/api/integrations";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Search, 
  FileText, 
  File, 
  FilePlus2, 
  FolderOpen, 
  Trash2, 
  MoreVertical, 
  FileCheck, 
  FileWarning,
  RefreshCw,
  EyeIcon,
  Link2,
  Calendar,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { format } from 'date-fns';
import DocumentProcessing from '../components/documents/DocumentProcessing';

export default function Documents() {
  const [documents, setDocuments] = useState([]);
  const [sources, setSources] = useState([]);
  const [gpts, setGpts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [selectedSource, setSelectedSource] = useState('all');
  const [selectedFileType, setSelectedFileType] = useState('all');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewDocument, setPreviewDocument] = useState(null);
  const [previewContent, setPreviewContent] = useState('');
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const docsData = await Document.list();
      const sourcesData = await DocumentSource.list();
      const gptsData = await GPT.list();
      
      setDocuments(docsData);
      setSources(sourcesData);
      setGpts(gptsData);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      alert(`File "${e.dataTransfer.files[0].name}" dropped. Upload functionality would be implemented here.`);
    }
  };

  const handleSelectDocument = (docId) => {
    setSelectedDocuments(prev => {
      if (prev.includes(docId)) {
        return prev.filter(id => id !== docId);
      } else {
        return [...prev, docId];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedDocuments.length === filteredDocuments.length) {
      setSelectedDocuments([]);
    } else {
      setSelectedDocuments(filteredDocuments.map(doc => doc.id));
    }
  };

  const openPreview = async (document) => {
    setPreviewDocument(document);
    setIsPreviewOpen(true);
    setIsPreviewLoading(true);
    setPreviewContent('');
    
    try {
      const fakeContent = await new Promise(resolve => {
        setTimeout(() => {
          resolve(`# ${document.title}\n\nThis is a preview of the document content. In a real implementation, this would show the actual content from the document.\n\n## Document Metadata\n\n* File Type: ${document.file_type.toUpperCase()}\n* Last Modified: ${document.metadata?.modified_date ? format(new Date(document.metadata.modified_date), 'PPP') : 'Unknown'}\n* Author: ${document.metadata?.author || 'Unknown'}\n* Size: ${document.metadata?.size_bytes ? Math.round(document.metadata.size_bytes / 1024) + ' KB' : 'Unknown'}\n* Pages: ${document.metadata?.page_count || 'Unknown'}`);
        }, 1500);
      });
      
      setPreviewContent(fakeContent);
    } catch (error) {
      setPreviewContent('Error loading document preview.');
    } finally {
      setIsPreviewLoading(false);
    }
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSource = selectedSource === 'all' || doc.source_id === selectedSource;
    const matchesFileType = selectedFileType === 'all' || doc.file_type === selectedFileType;
    
    return matchesSearch && matchesSource && matchesFileType;
  });

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Document Management</h1>
          <p className="text-gray-500">Connect and manage documents for your GPTs</p>
        </div>
        <Button
          onClick={() => window.location.href = createPageUrl("DocumentSources")}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <FolderOpen className="w-4 h-4 mr-2" />
          Manage Sources
        </Button>
      </div>

      <Tabs defaultValue="documents">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="upload">Upload</TabsTrigger>
          <TabsTrigger value="processing">Processing</TabsTrigger>
        </TabsList>
        
        <TabsContent value="documents" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Document Library</CardTitle>
              <CardDescription>
                Manage documents from all connected sources
              </CardDescription>
              
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search documents..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                
                <Select value={selectedSource} onValueChange={setSelectedSource}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sources</SelectItem>
                    {sources.map(source => (
                      <SelectItem key={source.id} value={source.id}>
                        {source.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={selectedFileType} onValueChange={setSelectedFileType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by file type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="pdf">PDF</SelectItem>
                    <SelectItem value="docx">Word (DOCX)</SelectItem>
                    <SelectItem value="xlsx">Excel (XLSX)</SelectItem>
                    <SelectItem value="pptx">PowerPoint (PPTX)</SelectItem>
                    <SelectItem value="txt">Text (TXT)</SelectItem>
                    <SelectItem value="html">HTML</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
                </div>
              ) : filteredDocuments.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">No documents found</h3>
                  <p className="text-gray-500 mt-2">
                    {searchTerm || selectedSource !== 'all' || selectedFileType !== 'all' 
                      ? "Try adjusting your filters" 
                      : "Connect a document source or upload documents to get started"}
                  </p>
                </div>
              ) : (
                <div className="rounded-md border overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox 
                            checked={selectedDocuments.length === filteredDocuments.length && filteredDocuments.length > 0}
                            onCheckedChange={handleSelectAll}
                          />
                        </TableHead>
                        <TableHead>Document</TableHead>
                        <TableHead>Source</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Last Updated</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDocuments.map(document => {
                        const source = sources.find(s => s.id === document.source_id);
                        
                        return (
                          <TableRow key={document.id}>
                            <TableCell>
                              <Checkbox 
                                checked={selectedDocuments.includes(document.id)}
                                onCheckedChange={() => handleSelectDocument(document.id)}
                              />
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div className="flex-shrink-0">
                                  {document.file_type === 'pdf' ? (
                                    <File className="h-8 w-8 text-red-400" />
                                  ) : document.file_type === 'docx' ? (
                                    <File className="h-8 w-8 text-blue-400" />
                                  ) : document.file_type === 'xlsx' ? (
                                    <File className="h-8 w-8 text-green-400" />
                                  ) : document.file_type === 'pptx' ? (
                                    <File className="h-8 w-8 text-orange-400" />
                                  ) : (
                                    <File className="h-8 w-8 text-gray-400" />
                                  )}
                                </div>
                                <div>
                                  <div className="font-medium">{document.title}</div>
                                  <div className="text-xs text-gray-500 flex items-center gap-1">
                                    <Badge variant="outline" className="text-xs px-1 py-0">
                                      {document.file_type.toUpperCase()}
                                    </Badge>
                                    {document.metadata?.size_bytes && (
                                      <span>{Math.round(document.metadata.size_bytes / 1024)} KB</span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              {source ? (
                                <div className="flex items-center gap-1">
                                  {source.type === 'google_drive' ? (
                                    <Badge className="bg-red-100 text-red-800">Google Drive</Badge>
                                  ) : source.type === 'onedrive' ? (
                                    <Badge className="bg-blue-100 text-blue-800">OneDrive</Badge>
                                  ) : source.type === 'dropbox' ? (
                                    <Badge className="bg-blue-100 text-blue-800">Dropbox</Badge>
                                  ) : source.type === 'box' ? (
                                    <Badge className="bg-indigo-100 text-indigo-800">Box</Badge>
                                  ) : source.type === 'sharepoint' ? (
                                    <Badge className="bg-green-100 text-green-800">SharePoint</Badge>
                                  ) : (
                                    <Badge className="bg-gray-100 text-gray-800">Local</Badge>
                                  )}
                                </div>
                              ) : (
                                <span className="text-gray-500">Unknown</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {document.is_indexed ? (
                                <div className="flex items-center gap-1 text-green-600">
                                  <FileCheck className="h-4 w-4" />
                                  <span>Indexed</span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1 text-amber-600">
                                  <FileWarning className="h-4 w-4" />
                                  <span>Not Indexed</span>
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              {document.last_indexed ? (
                                format(new Date(document.last_indexed), 'PPP')
                              ) : (
                                <span className="text-gray-500">—</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => openPreview(document)}
                                  className="h-8 w-8 p-0"
                                >
                                  <EyeIcon className="h-4 w-4" />
                                </Button>
                                
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 p-0"
                                    >
                                      <MoreVertical className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={() => alert('Reindex option clicked')}>
                                      <RefreshCw className="h-4 w-4 mr-2" />
                                      Reindex
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => alert('Link to GPT option clicked')}>
                                      <Link2 className="h-4 w-4 mr-2" />
                                      Link to GPT
                                    </DropdownMenuItem>
                                    <DropdownMenuItem 
                                      className="text-red-600"
                                      onClick={() => alert('Remove option clicked')}
                                    >
                                      <Trash2 className="h-4 w-4 mr-2" />
                                      Remove
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
            
            {selectedDocuments.length > 0 && (
              <CardFooter className="border-t bg-gray-50 p-4">
                <div className="flex items-center justify-between w-full">
                  <div>
                    <span className="text-sm text-gray-600">
                      {selectedDocuments.length} document{selectedDocuments.length > 1 ? 's' : ''} selected
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => alert('Bulk index clicked')}>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Index Selected
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => alert('Bulk link clicked')}>
                      <Link2 className="h-4 w-4 mr-2" />
                      Link to GPT
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-red-600 border-red-200 hover:bg-red-50"
                      onClick={() => alert('Bulk remove clicked')}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remove Selected
                    </Button>
                  </div>
                </div>
              </CardFooter>
            )}
          </Card>
        </TabsContent>
        
        <TabsContent value="upload" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upload Documents</CardTitle>
              <CardDescription>
                Upload documents to be used with your GPTs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div 
                className={`border-2 border-dashed rounded-lg p-12 text-center ${
                  dragActive ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <FilePlus2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">
                  {dragActive ? 'Drop files here' : 'Upload documents'}
                </h3>
                <p className="text-gray-500 mt-2">
                  Drag and drop files here, or click to select files
                </p>
                <p className="text-gray-400 text-sm mt-1">
                  Supports PDF, DOCX, XLSX, PPTX, TXT, HTML (Max 50MB)
                </p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => document.getElementById('file-upload').click()}
                >
                  Select Files
                </Button>
                <input 
                  id="file-upload" 
                  type="file" 
                  multiple 
                  className="hidden" 
                  onChange={(e) => {
                    if (e.target.files.length) {
                      alert(`${e.target.files.length} file(s) selected. Upload functionality would be implemented here.`);
                    }
                  }}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="processing">
          <DocumentProcessing />
        </TabsContent>
      </Tabs>
      
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {previewDocument?.file_type === 'pdf' ? (
                <File className="h-5 w-5 text-red-400" />
              ) : previewDocument?.file_type === 'docx' ? (
                <File className="h-5 w-5 text-blue-400" />
              ) : previewDocument?.file_type === 'xlsx' ? (
                <File className="h-5 w-5 text-green-400" />
              ) : previewDocument?.file_type === 'pptx' ? (
                <File className="h-5 w-5 text-orange-400" />
              ) : (
                <File className="h-5 w-5 text-gray-400" />
              )}
              {previewDocument?.title}
            </DialogTitle>
            <DialogDescription>
              Document preview and information
            </DialogDescription>
          </DialogHeader>
          
          {isPreviewLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
            </div>
          ) : (
            <div className="mt-2">
              <div className="rounded border p-4 bg-gray-50 h-[300px] overflow-y-auto font-mono text-sm whitespace-pre-wrap">
                {previewContent}
              </div>
              
              <div className="mt-4 grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-2">Document Information</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Type:</span>
                      <span>{previewDocument?.file_type.toUpperCase()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Size:</span>
                      <span>{previewDocument?.metadata?.size_bytes ? Math.round(previewDocument.metadata.size_bytes / 1024) + ' KB' : 'Unknown'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Pages:</span>
                      <span>{previewDocument?.metadata?.page_count || 'Unknown'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Author:</span>
                      <span>{previewDocument?.metadata?.author || 'Unknown'}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-2">Indexing Status</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Status:</span>
                      <span className={`flex items-center gap-1 ${previewDocument?.is_indexed ? 'text-green-600' : 'text-amber-600'}`}>
                        {previewDocument?.is_indexed ? (
                          <>
                            <CheckCircle2 className="h-3 w-3" />
                            Indexed
                          </>
                        ) : (
                          <>
                            <AlertCircle className="h-3 w-3" />
                            Not Indexed
                          </>
                        )}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Last Indexed:</span>
                      <span>{previewDocument?.last_indexed ? format(new Date(previewDocument.last_indexed), 'PPP') : '—'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Last Modified:</span>
                      <span>{previewDocument?.metadata?.modified_date ? format(new Date(previewDocument.metadata.modified_date), 'PPP') : '—'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>
              Close
            </Button>
            <Button onClick={() => alert('Index now clicked')}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Index Now
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
