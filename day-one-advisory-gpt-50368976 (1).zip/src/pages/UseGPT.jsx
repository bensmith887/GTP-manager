
import React, { useState, useEffect } from "react";
import { GPT } from '@/api/entities';
import { UserGPTAccess } from '@/api/entities';
import { User } from '@/api/entities';
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Wand2, Settings2, AlertCircle } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

export default function UseGPT() {
  const [gpts, setGpts] = useState([]);
  const [selectedGpt, setSelectedGpt] = useState(null);
  const [variables, setVariables] = useState({});
  const [output, setOutput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [userAccessDetails, setUserAccessDetails] = useState(null);

  useEffect(() => {
    checkUserAndLoadGPTs();
  }, []);

  useEffect(() => {
    if (selectedGpt) {
      const variableMatches = selectedGpt.system_prompt.match(/\{\{([^}]+)\}\}/g) || [];
      const uniqueVariables = [...new Set(variableMatches)].reduce((acc, variable) => {
        const cleanVar = variable.replace(/[{}]/g, "").trim();
        acc[cleanVar] = "";
        return acc;
      }, {});
      
      setVariables(uniqueVariables);
      setOutput("");
      setError("");
    }
  }, [selectedGpt]);

  const checkUserAndLoadGPTs = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      const userAccesses = await UserGPTAccess.filter({ 
        user_email: user.email, 
        is_active: true 
      });
      
      const currentAccess = userAccesses.length > 0 ? 
        userAccesses.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0] : null;
      
      setIsAdmin(currentAccess?.is_admin || user.role === 'admin');
      
      if (currentAccess?.is_admin || user.role === 'admin') {
        await loadAllGPTs();
      } else {
        await loadUserGPTs(user.email);
      }
    } catch (error) {
      console.error("Error checking user:", error);
      setError("Failed to authenticate. Please log in again.");
    }
  };

  const loadAllGPTs = async () => {
    try {
      const data = await GPT.list();
      const availableGpts = data.filter(gpt => gpt.is_active);
      setGpts(availableGpts);

      const urlParams = new URLSearchParams(window.location.search);
      const gptId = urlParams.get("id");
      if (gptId) {
        const gpt = availableGpts.find(g => g.id === gptId);
        if (gpt) setSelectedGpt(gpt);
      }
    } catch (error) {
      setError("Failed to load GPTs");
    }
  };

  const loadUserGPTs = async (userEmail) => {
    try {
      const userAccesses = await UserGPTAccess.filter({ user_email: userEmail, is_active: true });
      
      if (!userAccesses.length) {
        setGpts([]);
        setUserAccessDetails({ hasAccess: false });
        return;
      }
      
      const userAccess = userAccesses.sort((a, b) => {
        return new Date(b.created_date) - new Date(a.created_date);
      })[0];
      
      if (userAccess.expiry_date) {
        const expiryDate = new Date(userAccess.expiry_date);
        if (expiryDate < new Date()) {
          setUserAccessDetails({ 
            hasAccess: false, 
            isExpired: true,
            expiry_date: userAccess.expiry_date
          });
          setGpts([]);
          return;
        }
      }
      
      const allGpts = await GPT.list();
      const accessibleGpts = allGpts.filter(gpt => 
        gpt.is_active && userAccess.gpt_ids.includes(gpt.id)
      );
      
      setGpts(accessibleGpts);
      setUserAccessDetails({ 
        hasAccess: true, 
        expiry_date: userAccess.expiry_date
      });
      
      const urlParams = new URLSearchParams(window.location.search);
      const gptId = urlParams.get("id");
      if (gptId) {
        const gpt = accessibleGpts.find(g => g.id === gptId);
        if (gpt) setSelectedGpt(gpt);
      }
    } catch (error) {
      setError("Failed to load your accessible GPTs");
    }
  };

  const handleInputChange = (variable, value) => {
    setVariables(prev => ({
      ...prev,
      [variable]: value
    }));
  };

  const generateResponse = async () => {
    setIsLoading(true);
    setError("");
    
    try {
      let finalPrompt = selectedGpt.system_prompt;
      
      Object.entries(variables).forEach(([key, value]) => {
        finalPrompt = finalPrompt.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
      });

      if (selectedGpt.knowledge_base && (!variables.context || variables.context.trim() === "")) {
        finalPrompt = finalPrompt.replace(/\{\{context\}\}/g, selectedGpt.knowledge_base);
      }

      const response = await InvokeLLM({
        prompt: finalPrompt
      });

      setOutput(response);
    } catch (error) {
      setError("Failed to generate response. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const categoryColors = {
    business: "bg-blue-100 text-blue-800",
    creative: "bg-purple-100 text-purple-800",
    technical: "bg-green-100 text-green-800",
    academic: "bg-yellow-100 text-yellow-800",
    personal: "bg-pink-100 text-pink-800"
  };

  if (currentUser && !isAdmin && userAccessDetails && !userAccessDetails.hasAccess) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh]">
        <Card className="max-w-md w-full">
          <CardHeader>
            <div className="flex items-center gap-2 text-amber-600 justify-center">
              <AlertCircle className="w-5 h-5" />
              <CardTitle>{userAccessDetails.isExpired ? "Access Expired" : "No Access"}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="text-center">
            {userAccessDetails.isExpired ? (
              <>
                <p>Your access to GPTs has expired on {format(new Date(userAccessDetails.expiry_date), 'PPP')}.</p>
                <p className="mt-2 text-sm text-gray-500">
                  Please contact the administrator for extended access.
                </p>
              </>
            ) : (
              <>
                <p>You don't have access to any GPTs.</p>
                <p className="mt-2 text-sm text-gray-500">
                  Please contact the administrator to request access.
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      <Card className="border-none shadow-lg bg-white/80 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-xl text-gray-900">Select GPT</CardTitle>
          <CardDescription className="text-gray-600">
            Choose a GPT to start generating responses
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select
            value={selectedGpt?.id || ""}
            onValueChange={(value) => {
              const gpt = gpts.find(g => g.id === value);
              setSelectedGpt(gpt);
            }}
          >
            <SelectTrigger className="w-full transition-all duration-200 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1">
              <SelectValue placeholder="Select a GPT..." />
            </SelectTrigger>
            <SelectContent>
              {gpts.map((gpt) => (
                <SelectItem key={gpt.id} value={gpt.id}>
                  <div className="flex items-center gap-2">
                    <span>{gpt.name}</span>
                    <Badge className={categoryColors[gpt.category]}>
                      {gpt.category}
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedGpt && (
        <>
          <Card className="border-none shadow-lg bg-white/80 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900">Input Variables</CardTitle>
              <CardDescription className="text-gray-600">
                Fill in the required information for your prompt
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {Object.keys(variables).map((variable) => (
                <div key={variable} className="space-y-2">
                  <Label 
                    htmlFor={variable}
                    className="text-sm font-medium text-gray-700"
                  >
                    {variable.split('_').map(word => 
                      word.charAt(0).toUpperCase() + word.slice(1)
                    ).join(' ')}
                  </Label>
                  {variable.includes('message') || variable.includes('description') || variable === 'context' ? (
                    <Textarea
                      id={variable}
                      value={variables[variable]}
                      onChange={(e) => handleInputChange(variable, e.target.value)}
                      placeholder={`Enter ${variable.replace(/_/g, ' ')}...`}
                      className="h-24 transition-all duration-200 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1"
                    />
                  ) : (
                    <Input
                      id={variable}
                      value={variables[variable]}
                      onChange={(e) => handleInputChange(variable, e.target.value)}
                      placeholder={`Enter ${variable.replace(/_/g, ' ')}...`}
                      className="transition-all duration-200 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1"
                    />
                  )}
                </div>
              ))}
              <Button
                className="w-full bg-indigo-600 hover:bg-indigo-700 transition-all duration-200 shadow-sm hover:shadow mt-4"
                onClick={generateResponse}
                disabled={isLoading || Object.values(variables).some(v => !v.trim())}
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Generate Response
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {(output || error) && (
            <Card className="border-none shadow-lg bg-white/80 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">Generated Response</CardTitle>
              </CardHeader>
              <CardContent>
                {error ? (
                  <div className="text-red-500 p-4 bg-red-50 rounded-lg">
                    {error}
                  </div>
                ) : (
                  <div className="prose max-w-none">
                    <div className="whitespace-pre-wrap p-4 bg-gray-50 rounded-lg">
                      {output}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </>
      )}

      {gpts.length === 0 && !error && (
        <Card className="border-none shadow-lg bg-white/80 backdrop-blur">
          <CardContent className="py-12">
            <div className="text-center">
              <p className="text-gray-500 mb-4">No GPTs available.</p>
              {isAdmin && (
                <Link to={createPageUrl("ManageGPTs")}>
                  <Button 
                    variant="link" 
                    className="text-indigo-600 hover:text-indigo-700 transition-colors duration-200"
                  >
                    Create your first GPT
                  </Button>
                </Link>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
