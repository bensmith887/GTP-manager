
import React, { useState, useEffect } from "react";
import { UserGPTAccess } from "@/api/entities";
import { GPT } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Plus, Trash2, Search, Mail, Edit } from "lucide-react";
import { format } from "date-fns";
import { SendEmail } from "@/api/integrations";
import { createPageUrl } from "@/utils";

export default function ManageUserAccess() {
  const [userAccesses, setUserAccesses] = useState([]);
  const [gpts, setGpts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [isNewDialogOpen, setIsNewDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingAccess, setEditingAccess] = useState(null);
  const [deleteAccessId, setDeleteAccessId] = useState(null);
  const [isSending, setIsSending] = useState(false);
  const [showInactive, setShowInactive] = useState(false);

  const [formData, setFormData] = useState({
    user_email: "",
    gpt_ids: [],
    is_admin: false,
    expiry_date: null,
    notes: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (editingAccess) {
      setFormData({
        user_email: editingAccess.user_email,
        gpt_ids: editingAccess.gpt_ids || [],
        is_admin: editingAccess.is_admin || false,
        expiry_date: editingAccess.expiry_date ? new Date(editingAccess.expiry_date) : null,
        notes: editingAccess.notes || ""
      });
    } else {
      setFormData({
        user_email: "",
        gpt_ids: [],
        is_admin: false,
        expiry_date: null,
        notes: ""
      });
    }
  }, [editingAccess]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const accessData = await UserGPTAccess.list();
      setUserAccesses(accessData);
      const gptsData = await GPT.list('-created_date');
      setGpts(gptsData.filter(gpt => gpt.is_active));
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      if (editingAccess) {
        await UserGPTAccess.update(editingAccess.id, {
          gpt_ids: formData.gpt_ids,
          is_admin: formData.is_admin,
          expiry_date: formData.expiry_date,
          notes: formData.notes
        });
        setIsEditDialogOpen(false);
        setEditingAccess(null);
      } else {
        await UserGPTAccess.create({
          user_email: formData.user_email,
          gpt_ids: formData.gpt_ids,
          is_admin: formData.is_admin,
          expiry_date: formData.expiry_date,
          notes: formData.notes,
          is_active: true
        });
        setIsNewDialogOpen(false);
      }

      loadData();
      await sendInvitationEmail({
        ...formData,
        is_new: !editingAccess
      });

      alert(editingAccess ? "Access updated successfully!" : "Access created successfully!");
    } catch (error) {
      console.error("Error saving access:", error);
      alert("Error: " + (error.message || "Failed to save access"));
    }
  };

  const sendInvitationEmail = async (access) => {
    try {
      const accessGPTs = access.gpt_ids
        .map(id => gpts.find(g => g.id === id))
        .filter(g => g)
        .map(g => g.name);
      
      const gptListHTML = accessGPTs.map(name => `<li>${name}</li>`).join('');
      const appUrl = window.location.origin + createPageUrl("UseGPT");
      
      const emailContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>${access.is_new ? "Welcome to" : "Updated Access to"} GPT Manager</h2>
          <p>Hello,</p>
          ${access.is_new ? `
            <p>You've been given access to the GPT Manager platform${access.is_admin ? " with administrative rights" : ""}.</p>
          ` : `
            <p>Your access to GPT Manager has been updated.</p>
          `}
          <p>You have access to the following GPTs:</p>
          <ul>${gptListHTML}</ul>
          <p>You can access ${access.is_admin ? "the platform" : "your GPTs"} by clicking below:</p>
          <p><a href="${appUrl}" style="display: inline-block; background-color: #4f46e5; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">Access ${access.is_admin ? "Platform" : "Your GPTs"}</a></p>
          <p>Or copy this link: ${appUrl}</p>
          ${access.expiry_date ? `<p><small>Note: Your access expires on ${format(new Date(access.expiry_date), 'PPP')}.</small></p>` : ''}
          ${access.is_admin ? `
            <p>As an administrator, you have access to:</p>
            <ul>
              <li>Manage GPTs</li>
              <li>Manage User Access</li>
              <li>Share GPTs</li>
            </ul>
          ` : ''}
          <p>Important: To access the platform, use your email address (${access.user_email}) and create your password on first login.</p>
          <p>If you have any questions, please contact the administrator.</p>
        </div>
      `;

      await SendEmail({
        to: access.user_email,
        subject: access.is_new ? "Welcome to GPT Manager" : "Updated GPT Manager Access",
        body: emailContent
      });
    } catch (error) {
      console.error("Error sending email:", error);
      alert("Access saved but failed to send email notification.");
    }
  };

  const handleDelete = async () => {
    try {
      await UserGPTAccess.update(deleteAccessId, {
        is_active: false
      });
      
      setDeleteAccessId(null);
      loadData();
      alert("Access deactivated successfully!");
    } catch (error) {
      console.error("Error deactivating access:", error);
      alert("Failed to deactivate access. Please try again.");
    }
  };

  const filteredAccesses = userAccesses
    .filter(access => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = access.user_email.toLowerCase().includes(searchLower) ||
                           (access.notes && access.notes.toLowerCase().includes(searchLower));
      
      const matchesActiveStatus = showInactive ? true : access.is_active;
      
      return matchesSearch && matchesActiveStatus;
    })
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Manage User Access</h1>
          <p className="text-gray-500">Control which users can access specific GPTs</p>
        </div>
        <Button 
          onClick={() => setIsNewDialogOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add User Access
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>User GPT Access</CardTitle>
          <CardDescription>
            Users with custom access to specific GPTs
          </CardDescription>
          <div className="mt-4 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by email or notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="show-inactive" 
                checked={showInactive}
                onCheckedChange={setShowInactive}
              />
              <Label htmlFor="show-inactive">Show inactive accounts</Label>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
            </div>
          ) : filteredAccesses.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              {searchTerm ? "No results match your search" : "No user access configurations yet"}
            </div>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User Email</TableHead>
                    <TableHead className="hidden md:table-cell">GPTs</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden md:table-cell">Expires</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAccesses.map((access) => {
                    const isExpired = access.expiry_date && new Date(access.expiry_date) < new Date();
                    const accessGPTs = access.gpt_ids
                      .map(id => gpts.find(g => g.id === id))
                      .filter(g => g);

                    return (
                      <TableRow key={access.id}>
                        <TableCell className="font-medium">{access.user_email}</TableCell>
                        <TableCell className="hidden md:table-cell">
                          <div className="flex flex-wrap gap-1">
                            {accessGPTs.length > 0 ? (
                              <>
                                <span className="md:hidden">{accessGPTs.length} GPTs</span>
                                <div className="hidden md:flex flex-wrap gap-1">
                                  {accessGPTs.map(gpt => (
                                    <Badge key={gpt.id} variant="outline" className="text-xs">
                                      {gpt.name}
                                    </Badge>
                                  ))}
                                </div>
                              </>
                            ) : (
                              <span className="text-gray-400 text-sm">No GPTs</span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={access.is_admin ? 
                            "bg-purple-100 text-purple-800" : 
                            "bg-blue-100 text-blue-800"
                          }>
                            {access.is_admin ? "Admin" : "User"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {!access.is_active ? (
                            <Badge variant="outline" className="text-gray-500">Inactive</Badge>
                          ) : isExpired ? (
                            <Badge variant="outline" className="text-amber-600">Expired</Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-800">Active</Badge>
                          )}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {access.expiry_date ? format(new Date(access.expiry_date), 'MMM d, yyyy') : "—"}
                        </TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 text-indigo-500 hover:text-indigo-700 hover:bg-indigo-50"
                              onClick={() => {
                                setEditingAccess(access);
                                setIsEditDialogOpen(true);
                              }}
                              title="Edit access"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                              onClick={() => sendInvitationEmail(access)}
                              disabled={isSending}
                              title="Send invitation"
                            >
                              <Mail className="h-4 w-4" />
                            </Button>
                            {access.is_active && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                                onClick={() => setDeleteAccessId(access.id)}
                                title="Deactivate access"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isNewDialogOpen} onOpenChange={setIsNewDialogOpen}>
        <DialogContent className="sm:max-w-[600px] h-[90vh] md:h-auto overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add User Access</DialogTitle>
            <DialogDescription>
              Give a user access to specific GPTs
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="user_email">User Email*</Label>
              <Input
                id="user_email"
                value={formData.user_email}
                onChange={(e) => setFormData({...formData, user_email: e.target.value})}
                placeholder="Enter user's email"
              />
            </div>

            <div className="space-y-2">
              <Label>Access Level</Label>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is_admin"
                  checked={formData.is_admin}
                  onCheckedChange={(checked) => {
                    setFormData({...formData, is_admin: checked});
                  }}
                />
                <label
                  htmlFor="is_admin"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Grant administrative rights
                </label>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                Admins can manage GPTs, user access, and sharing settings
              </p>
            </div>

            <div className="space-y-2">
              <Label>GPT Access*</Label>
              <div className="border rounded-md p-4 max-h-60 overflow-y-auto space-y-2">
                {gpts.length === 0 ? (
                  <p className="text-sm text-gray-500">No active GPTs available</p>
                ) : (
                  gpts.map((gpt) => (
                    <div key={gpt.id} className="flex items-start space-x-2">
                      <Checkbox
                        id={gpt.id}
                        checked={formData.gpt_ids.includes(gpt.id)}
                        onCheckedChange={(checked) => {
                          setFormData({
                            ...formData,
                            gpt_ids: checked 
                              ? [...formData.gpt_ids, gpt.id]
                              : formData.gpt_ids.filter(id => id !== gpt.id)
                          });
                        }}
                      />
                      <div className="grid gap-1.5 leading-none">
                        <label
                          htmlFor={gpt.id}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2"
                        >
                          {gpt.name}
                          <Badge className={`text-xs ${
                            gpt.category === "business" ? "bg-blue-100 text-blue-800" :
                            gpt.category === "technical" ? "bg-green-100 text-green-800" :
                            gpt.category === "creative" ? "bg-purple-100 text-purple-800" :
                            gpt.category === "academic" ? "bg-yellow-100 text-yellow-800" :
                            "bg-gray-100 text-gray-800"
                          }`}>
                            {gpt.category}
                          </Badge>
                        </label>
                        {gpt.description && (
                          <p className="text-xs text-gray-500 line-clamp-2">{gpt.description}</p>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Expiry Date (optional)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.expiry_date ? (
                      format(formData.expiry_date, "PPP")
                    ) : (
                      <span>No expiry date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.expiry_date}
                    onSelect={(date) => setFormData({...formData, expiry_date: date})}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-1 h-auto p-0 text-indigo-600"
                onClick={() => setFormData({...formData, expiry_date: null})}
              >
                Clear expiry date
              </Button>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Internal Only)</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="Add any notes about this access"
                className="h-20"
              />
            </div>
          </div>

          <DialogFooter className="sm:justify-end">
            <Button
              variant="outline"
              onClick={() => setIsNewDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              className="bg-indigo-600 hover:bg-indigo-700"
              onClick={handleSubmit}
              disabled={!formData.user_email || formData.gpt_ids.length === 0}
            >
              Add Access
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isEditDialogOpen} onOpenChange={(open) => {
        if (!open) setEditingAccess(null);
        setIsEditDialogOpen(open);
      }}>
        <DialogContent className="sm:max-w-[600px] h-[90vh] md:h-auto overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit User Access</DialogTitle>
            <DialogDescription>
              Update access for {editingAccess?.user_email}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Access Level</Label>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is_admin_edit"
                  checked={formData.is_admin}
                  onCheckedChange={(checked) => {
                    setFormData({...formData, is_admin: checked});
                  }}
                />
                <label
                  htmlFor="is_admin_edit"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Grant administrative rights
                </label>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                Admins can manage GPTs, user access, and sharing settings
              </p>
            </div>

            <div className="space-y-2">
              <Label>GPT Access*</Label>
              <div className="border rounded-md p-4 max-h-60 overflow-y-auto space-y-2">
                {gpts.length === 0 ? (
                  <p className="text-sm text-gray-500">No active GPTs available</p>
                ) : (
                  gpts.map((gpt) => (
                    <div key={gpt.id} className="flex items-start space-x-2">
                      <Checkbox
                        id={`edit-${gpt.id}`}
                        checked={formData.gpt_ids.includes(gpt.id)}
                        onCheckedChange={(checked) => {
                          setFormData({
                            ...formData,
                            gpt_ids: checked 
                              ? [...formData.gpt_ids, gpt.id]
                              : formData.gpt_ids.filter(id => id !== gpt.id)
                          });
                        }}
                      />
                      <div className="grid gap-1.5 leading-none">
                        <label
                          htmlFor={`edit-${gpt.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2"
                        >
                          {gpt.name}
                          <Badge className={`text-xs ${
                            gpt.category === "business" ? "bg-blue-100 text-blue-800" :
                            gpt.category === "technical" ? "bg-green-100 text-green-800" :
                            gpt.category === "creative" ? "bg-purple-100 text-purple-800" :
                            gpt.category === "academic" ? "bg-yellow-100 text-yellow-800" :
                            "bg-gray-100 text-gray-800"
                          }`}>
                            {gpt.category}
                          </Badge>
                        </label>
                        {gpt.description && (
                          <p className="text-xs text-gray-500 line-clamp-2">{gpt.description}</p>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Expiry Date (optional)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.expiry_date ? (
                      format(formData.expiry_date, "PPP")
                    ) : (
                      <span>No expiry date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.expiry_date}
                    onSelect={(date) => setFormData({...formData, expiry_date: date})}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-1 h-auto p-0 text-indigo-600"
                onClick={() => setFormData({...formData, expiry_date: null})}
              >
                Clear expiry date
              </Button>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Internal Only)</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="Add any notes about this access"
                className="h-20"
              />
            </div>
          </div>

          <DialogFooter className="sm:justify-end">
            <Button
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false);
                setEditingAccess(null);
              }}
            >
              Cancel
            </Button>
            <Button
              className="bg-indigo-600 hover:bg-indigo-700"
              onClick={handleSubmit}
              disabled={formData.gpt_ids.length === 0}
            >
              Update Access
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteAccessId} onOpenChange={(open) => !open && setDeleteAccessId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate User Access</AlertDialogTitle>
            <AlertDialogDescription>
              This will revoke the user's access to the specified GPTs.
              Are you sure?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Yes, Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
