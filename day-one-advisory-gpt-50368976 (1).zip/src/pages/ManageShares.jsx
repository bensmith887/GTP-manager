import React, { useState, useEffect } from "react";
import { GPTShare } from "@/api/entities";
import { GPT } from "@/api/entities";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Copy, ExternalLink, Mail, Trash2, Search } from "lucide-react";
import { format } from "date-fns";
import { createPageUrl } from "@/utils";
import { SendEmail } from "@/api/integrations";

export default function ManageShares() {
  const [shares, setShares] = useState([]);
  const [gpts, setGpts] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [deleteShareId, setDeleteShareId] = useState(null);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Load all shares
      const shareData = await GPTShare.list();
      setShares(shareData);

      // Load all GPTs and create a map for quick lookup
      const gptsData = await GPT.list();
      const gptsMap = {};
      gptsData.forEach(gpt => {
        gptsMap[gpt.id] = gpt;
      });
      setGpts(gptsMap);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteShareId) return;
    
    try {
      await GPTShare.update(deleteShareId, { is_active: false });
      loadData();
    } catch (error) {
      console.error("Error deleting share:", error);
      alert("Failed to delete share. Please try again.");
    } finally {
      setDeleteShareId(null);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copied to clipboard!");
  };

  const resendInvitation = async (share) => {
    setIsSending(true);
    try {
      const gpt = gpts[share.gpt_id];
      if (!gpt) throw new Error("GPT not found");
      
      const shareUrl = window.location.origin + createPageUrl("SharedGPT", `code=${share.share_code}`);
      
      await SendEmail({
        to: share.recipient_email,
        subject: `Access to "${gpt.name}" GPT`,
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2>You've been given access to a custom GPT</h2>
            <p>Hello ${share.recipient_name || "there"},</p>
            <p>You've been given access to use the "${gpt.name}" GPT.</p>
            <p><strong>Description:</strong> ${gpt.description || "No description provided."}</p>
            <p>Click the link below to access it:</p>
            <p><a href="${shareUrl}" style="display: inline-block; background-color: #4f46e5; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">Access Your GPT</a></p>
            <p>Or copy this link: ${shareUrl}</p>
            ${share.expiry_date ? `<p><small>Note: Your access expires on ${format(new Date(share.expiry_date), 'PPP')}.</small></p>` : ''}
            <p>If you have any questions, please contact the administrator.</p>
          </div>
        `
      });
      
      alert("Invitation email has been resent successfully!");
    } catch (error) {
      console.error("Error sending email:", error);
      alert("Failed to send invitation. Please try again.");
    } finally {
      setIsSending(false);
    }
  };

  const filteredShares = shares
    .filter(share => {
      const searchLower = searchTerm.toLowerCase();
      return (
        share.recipient_email.toLowerCase().includes(searchLower) ||
        (share.recipient_name && share.recipient_name.toLowerCase().includes(searchLower)) ||
        (share.company && share.company.toLowerCase().includes(searchLower)) ||
        (gpts[share.gpt_id]?.name && gpts[share.gpt_id].name.toLowerCase().includes(searchLower))
      );
    })
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  return (
    <div className="space-y-6 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Manage Shared GPTs</h1>
          <p className="text-gray-500">Track and manage all your shared GPT links</p>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Shared GPT Access</CardTitle>
          <CardDescription>
            All GPTs that have been shared with external users
          </CardDescription>
          <div className="mt-2 relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by name, email, company or GPT name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
            </div>
          ) : filteredShares.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              {searchTerm ? "No results match your search" : "No GPTs have been shared yet"}
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>GPT Name</TableHead>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredShares.map((share) => {
                    const gpt = gpts[share.gpt_id];
                    const isExpired = share.expiry_date && new Date(share.expiry_date) < new Date();
                    const shareUrl = window.location.origin + createPageUrl("SharedGPT", `code=${share.share_code}`);

                    return (
                      <TableRow key={share.id}>
                        <TableCell className="font-medium">{gpt?.name || "Unknown GPT"}</TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span>{share.recipient_name || "—"}</span>
                            <span className="text-xs text-gray-500">{share.recipient_email}</span>
                          </div>
                        </TableCell>
                        <TableCell>{share.company || "—"}</TableCell>
                        <TableCell>
                          {!share.is_active ? (
                            <Badge variant="outline" className="text-gray-500">Inactive</Badge>
                          ) : isExpired ? (
                            <Badge variant="outline" className="text-amber-600">Expired</Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-800">Active</Badge>
                          )}
                        </TableCell>
                        <TableCell>{format(new Date(share.created_date), 'MMM d, yyyy')}</TableCell>
                        <TableCell>
                          {share.expiry_date ? format(new Date(share.expiry_date), 'MMM d, yyyy') : "—"}
                        </TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0"
                              onClick={() => copyToClipboard(shareUrl)}
                              title="Copy link"
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                              onClick={() => window.open(shareUrl, "_blank")}
                              title="Open link"
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 text-indigo-500 hover:text-indigo-700 hover:bg-indigo-50"
                              onClick={() => resendInvitation(share)}
                              disabled={isSending}
                              title="Resend invitation"
                            >
                              <Mail className="h-4 w-4" />
                            </Button>
                            {share.is_active && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                                onClick={() => setDeleteShareId(share.id)}
                                title="Deactivate share"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteShareId} onOpenChange={(open) => !open && setDeleteShareId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Shared Access</AlertDialogTitle>
            <AlertDialogDescription>
              This will revoke access to the GPT. The recipient will no longer be able to access it.
              Are you sure?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Yes, Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}