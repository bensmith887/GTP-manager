import React, { useState, useEffect } from 'react';
import { DocumentSource } from '@/api/entities';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  RefreshCw, 
  Trash2, 
  UploadCloud,
  Cloud,
  Database,
  Check,
  AlertCircle
} from 'lucide-react';

export default function DocumentSources() {
  const [sources, setSources] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingSource, setIsAddingSource] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState(null);
  
  useEffect(() => {
    loadSources();
  }, []);

  const loadSources = async () => {
    setIsLoading(true);
    try {
      const data = await DocumentSource.list();
      setSources(data);
    } catch (error) {
      console.error('Error loading sources:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const initializeOAuth = async (platform) => {
    // This would be handled by your OAuth integration
    alert('OAuth integration will be implemented here');
  };

  const platforms = [
    { id: 'google_drive', name: 'Google Drive', icon: Cloud },
    { id: 'onedrive', name: 'OneDrive', icon: Cloud },
    { id: 'dropbox', name: 'Dropbox', icon: UploadCloud },
    { id: 'box', name: 'Box', icon: Database },
    { id: 'sharepoint', name: 'SharePoint', icon: Database }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Document Sources</h1>
          <p className="text-gray-500">Manage your external document storage connections</p>
        </div>
        <Button 
          onClick={() => setIsAddingSource(true)}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Source
        </Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
        </div>
      ) : sources.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <UploadCloud className="h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-500 text-center mb-4">
              No document sources connected yet
            </p>
            <Button 
              onClick={() => setIsAddingSource(true)}
              variant="outline"
            >
              Connect Your First Source
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {sources.map((source) => {
            const platform = platforms.find(p => p.id === source.type);
            const Icon = platform?.icon || Cloud;
            
            return (
              <Card key={source.id} className="relative overflow-hidden">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Icon className="h-5 w-5" />
                    {source.name}
                  </CardTitle>
                  <CardDescription>
                    {platform?.name || 'External Storage'}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Badge className={source.is_active ? 
                        "bg-green-100 text-green-800" : 
                        "bg-gray-100 text-gray-800"
                      }>
                        {source.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                      {source.last_sync && (
                        <Badge variant="outline" className="text-gray-600">
                          Last synced: {new Date(source.last_sync).toLocaleDateString()}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="flex-1"
                        onClick={() => {/* Implement sync */}}
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Sync
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => {/* Implement disconnect */}}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Disconnect
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isAddingSource} onOpenChange={setIsAddingSource}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Document Source</DialogTitle>
            <DialogDescription>
              Connect an external storage platform to index documents
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Storage Platform</Label>
              <Select
                value={selectedPlatform}
                onValueChange={setSelectedPlatform}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a platform" />
                </SelectTrigger>
                <SelectContent>
                  {platforms.map((platform) => (
                    <SelectItem 
                      key={platform.id} 
                      value={platform.id}
                      className="flex items-center gap-2"
                    >
                      <platform.icon className="h-4 w-4" />
                      {platform.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Display Name</Label>
              <Input 
                placeholder="e.g., Company Google Drive"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddingSource(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={() => selectedPlatform && initializeOAuth(selectedPlatform)}
              disabled={!selectedPlatform}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              Connect Platform
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}