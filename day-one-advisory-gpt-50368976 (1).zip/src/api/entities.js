import { base44 } from './base44Client';


export const GPT = base44.entities.GPT;

export const GPTShare = base44.entities.GPTShare;

export const UserGPTAccess = base44.entities.UserGPTAccess;

export const DocumentSource = base44.entities.DocumentSource;

export const Document = base44.entities.Document;

export const DocumentPermission = base44.entities.DocumentPermission;

export const DocumentChunk = base44.entities.DocumentChunk;

export const RAGSettings = base44.entities.RAGSettings;

export const Subscription = base44.entities.Subscription;

export const SubscriptionPlan = base44.entities.SubscriptionPlan;

export const BillingTransaction = base44.entities.BillingTransaction;

export const Tenant = base44.entities.Tenant;



// auth sdk:
export const User = base44.auth;