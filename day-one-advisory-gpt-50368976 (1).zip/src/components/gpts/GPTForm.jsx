
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { AlertCircle, PlusCircle, Clipboard, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Tooltip,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import GPTKnowledgeIntegration from "@/components/gpts/GPTKnowledgeIntegration"; // Fixed import path
import { BookOpen } from "lucide-react";

export default function GPTForm({ gpt, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    name: gpt?.name || "",
    description: gpt?.description || "",
    system_prompt: gpt?.system_prompt || "",
    knowledge_base: gpt?.knowledge_base || "",
    category: gpt?.category || "business",
    is_active: gpt?.is_active ?? true
  });

  const [errors, setErrors] = useState({});
  const [activeTab, setActiveTab] = useState('basic');

  const getCategoryVariables = (category) => {
    const coreVariables = {
      name: "Core Inputs",
      variables: [
        { id: "user_input", label: "User Input", description: "The user's current message or query" },
        { id: "context", label: "Context", description: "Additional context from knowledge base" },
        { id: "previous_messages", label: "Previous Messages", description: "Chat history between user and GPT" }
      ]
    };

    const categorySpecificVariables = {
      business: [
        {
          name: "Business Analysis",
          variables: [
            { id: "company", label: "Company", description: "Company name for business analysis" },
            { id: "industry", label: "Industry", description: "Industry sector for market analysis" },
            { id: "competitors", label: "Competitors", description: "Key competitors in the market" },
            { id: "market_size", label: "Market Size", description: "Size and growth of the target market" }
          ]
        },
        {
          name: "Business Strategy",
          variables: [
            { id: "goals", label: "Business Goals", description: "Short and long-term business objectives" },
            { id: "swot", label: "SWOT", description: "Strengths, weaknesses, opportunities, and threats" },
            { id: "budget", label: "Budget", description: "Available resources and financial constraints" },
            { id: "timeframe", label: "Timeframe", description: "Time period for business strategy" }
          ]
        }
      ],
      creative: [
        {
          name: "Creative Content",
          variables: [
            { id: "creative_style", label: "Style", description: "Creative style or art direction" },
            { id: "theme", label: "Theme", description: "Central theme or concept for creative work" },
            { id: "medium", label: "Medium", description: "Format or medium of creative output" },
            { id: "audience", label: "Target Audience", description: "Who the creative content is intended for" }
          ]
        },
        {
          name: "Writing Parameters",
          variables: [
            { id: "genre", label: "Genre", description: "Literary or content genre" },
            { id: "tone", label: "Tone", description: "Emotional tone of the content" },
            { id: "character", label: "Character", description: "Main character or persona" },
            { id: "setting", label: "Setting", description: "Time and place for the content" }
          ]
        }
      ],
      technical: [
        {
          name: "Development",
          variables: [
            { id: "language", label: "Programming Language", description: "Coding language to use" },
            { id: "framework", label: "Framework", description: "Software framework or library" },
            { id: "platform", label: "Platform", description: "Target platform or environment" },
            { id: "requirements", label: "Requirements", description: "Technical requirements and specifications" }
          ]
        },
        {
          name: "Technical Documentation",
          variables: [
            { id: "api_endpoint", label: "API Endpoint", description: "Specific API or service endpoint" },
            { id: "code_example", label: "Code Example", description: "Example code to explain or improve" },
            { id: "error_message", label: "Error Message", description: "Error output to troubleshoot" },
            { id: "tech_stack", label: "Tech Stack", description: "Technology stack information" }
          ]
        }
      ],
      academic: [
        {
          name: "Research Parameters",
          variables: [
            { id: "research_question", label: "Research Question", description: "Primary question to investigate" },
            { id: "methodology", label: "Methodology", description: "Research approach or methodology" },
            { id: "field", label: "Field", description: "Academic field or discipline" },
            { id: "sources", label: "Sources", description: "Reference sources to include" }
          ]
        },
        {
          name: "Academic Writing",
          variables: [
            { id: "citation_style", label: "Citation Style", description: "Academic citation format (APA, MLA, etc.)" },
            { id: "academic_level", label: "Academic Level", description: "Education level (undergraduate, graduate, etc.)" },
            { id: "thesis", label: "Thesis", description: "Main argument or thesis statement" },
            { id: "keywords", label: "Keywords", description: "Key terms for the academic work" }
          ]
        }
      ],
      personal: [
        {
          name: "Personal Assistance",
          variables: [
            { id: "personal_goal", label: "Personal Goal", description: "Individual goal or objective" },
            { id: "preferences", label: "Preferences", description: "Personal preferences and likes" },
            { id: "constraints", label: "Constraints", description: "Personal limitations or restrictions" },
            { id: "background", label: "Background", description: "Relevant personal background" }
          ]
        },
        {
          name: "Life Management",
          variables: [
            { id: "schedule", label: "Schedule", description: "Time availability and constraints" },
            { id: "location", label: "Location", description: "Geographical location" },
            { id: "skills", label: "Skills", description: "Personal skills and capabilities" },
            { id: "resources", label: "Resources", description: "Available personal resources" }
          ]
        }
      ]
    };

    return [coreVariables, ...(categorySpecificVariables[category] || [])];
  };

  const variableCategories = getCategoryVariables(formData.category);

  const insertVariable = (variable) => {
    const textarea = document.getElementById("system-prompt");
    const cursorPos = textarea.selectionStart;
    const textBefore = formData.system_prompt.substring(0, cursorPos);
    const textAfter = formData.system_prompt.substring(cursorPos);
    
    const newPrompt = `${textBefore}{{${variable}}}${textAfter}`;
    setFormData({ ...formData, system_prompt: newPrompt });
    
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = cursorPos + variable.length + 4; 
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }
    if (!formData.system_prompt.trim()) {
      newErrors.system_prompt = "System prompt is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="basic">Basic Settings</TabsTrigger>
          <TabsTrigger value="knowledge">Knowledge Integration</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-6 pt-4">
          <div className="grid gap-6">
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-sm font-medium text-gray-700">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Business Consultant GPT"
                  className="transition-all duration-200 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1"
                />
                {errors.name && (
                  <p className="text-sm text-red-500 mt-1">{errors.name}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="category" className="text-sm font-medium text-gray-700">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger className="transition-all duration-200">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="creative">Creative</SelectItem>
                    <SelectItem value="technical">Technical</SelectItem>
                    <SelectItem value="academic">Academic</SelectItem>
                    <SelectItem value="personal">Personal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-sm font-medium text-gray-700">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="What does this GPT do? How should it be used?"
                className="h-24"
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>System Prompt</CardTitle>
                <CardDescription>
                  Define how your GPT should behave and interact. Use variables to make your prompt dynamic.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gray-50 border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-700">Insert Variables</h4>
                    <button 
                      type="button"
                      className="h-8 w-8 p-0 flex items-center justify-center text-gray-500 hover:text-gray-700"
                      title="Variables are placeholders that will be replaced with actual values when the GPT is used."
                    >
                      <Info className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="space-y-3">
                    {variableCategories.map((category) => (
                      <div key={category.name} className="space-y-2">
                        <h5 className="text-sm font-medium text-gray-600">{category.name}</h5>
                        <div className="flex flex-wrap gap-2">
                          {category.variables.map((variable) => (
                            <Tooltip 
                              key={variable.id}
                              content={
                                <div>
                                  <p>{variable.description}</p>
                                  <p className="text-xs text-gray-500 mt-1">Click to insert {`{{${variable.id}}}`}</p>
                                </div>
                              }
                            >
                              <Badge 
                                variant="outline"
                                className="cursor-pointer hover:bg-indigo-50 transition-colors duration-200 flex items-center gap-1"
                                onClick={() => insertVariable(variable.id)}
                              >
                                <PlusCircle className="h-3 w-3" />
                                {variable.label}
                              </Badge>
                            </Tooltip>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="relative">
                  <Textarea
                    id="system-prompt"
                    value={formData.system_prompt}
                    onChange={(e) => setFormData({ ...formData, system_prompt: e.target.value })}
                    placeholder="You are an expert business consultant..."
                    className="min-h-[200px] font-mono text-sm pr-10"
                    spellCheck="false"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2 h-8 w-8 p-0 opacity-70 hover:opacity-100"
                    onClick={() => copyToClipboard(formData.system_prompt)}
                  >
                    <Clipboard className="h-4 w-4" />
                  </Button>
                </div>
                
                {errors.system_prompt && (
                  <p className="text-sm text-red-500">{errors.system_prompt}</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Knowledge Base</CardTitle>
                <CardDescription>
                  Add specific knowledge or guidelines that your GPT should reference.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={formData.knowledge_base}
                  onChange={(e) => setFormData({ ...formData, knowledge_base: e.target.value })}
                  placeholder="Add domain-specific knowledge..."
                  className="h-32"
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="knowledge" className="pt-4">
          {gpt?.id ? (
            <GPTKnowledgeIntegration gptId={gpt.id} />
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-10">
                <BookOpen className="h-12 w-12 text-gray-300 mb-4" />
                <p className="text-gray-500 text-center mb-4">
                  Save the GPT first to enable document knowledge integration
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-3 mt-6">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          {gpt ? "Update GPT" : "Create GPT"}
        </Button>
      </div>
    </form>
  );
}
