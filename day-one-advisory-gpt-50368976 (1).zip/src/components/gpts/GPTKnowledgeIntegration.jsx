import React, { useState, useEffect } from 'react';
import { GPT } from '@/api/entities';
import { Document } from '@/api/entities';
import { DocumentPermission } from '@/api/entities';
import { DocumentChunk } from '@/api/entities';
import { RAGSettings } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Link,
  FileText,
  Database,
  RefreshCw,
  Search,
  Settings,
  BookOpen,
  Network
} from 'lucide-react';

export default function GPTKnowledgeIntegration({ gptId }) {
  const [documents, setDocuments] = useState([]);
  const [connectedDocs, setConnectedDocs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [settings, setSettings] = useState({
    retrievalType: 'hybrid',
    relevanceThreshold: 0.7,
    maxResults: 5
  });

  useEffect(() => {
    loadData();
  }, [gptId]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Load connected documents
      const permissions = await DocumentPermission.filter({ gpt_id: gptId });
      const connectedDocIds = permissions.map(p => p.document_id);
      
      // Load all available documents
      const allDocs = await Document.list();
      
      setDocuments(allDocs);
      setConnectedDocs(connectedDocIds);
    } catch (error) {
      console.error("Error loading knowledge base:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleConnect = async (docId) => {
    try {
      await DocumentPermission.create({
        document_id: docId,
        gpt_id: gptId,
        access_level: 'read'
      });
      
      setConnectedDocs(prev => [...prev, docId]);
    } catch (error) {
      console.error("Error connecting document:", error);
    }
  };

  const handleDisconnect = async (docId) => {
    try {
      const permissions = await DocumentPermission.filter({
        document_id: docId,
        gpt_id: gptId
      });
      
      for (const permission of permissions) {
        await DocumentPermission.update(permission.id, { is_active: false });
      }
      
      setConnectedDocs(prev => prev.filter(id => id !== docId));
    } catch (error) {
      console.error("Error disconnecting document:", error);
    }
  };

  const testKnowledgeRetrieval = async () => {
    setIsProcessing(true);
    try {
      // Simulate knowledge retrieval test
      await new Promise(resolve => setTimeout(resolve, 2000));
      // In a real implementation, this would test the retrieval system
      alert("Knowledge retrieval test completed successfully!");
    } catch (error) {
      console.error("Error testing knowledge retrieval:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Tabs defaultValue="documents">
      <TabsList>
        <TabsTrigger value="documents">Connected Documents</TabsTrigger>
        <TabsTrigger value="settings">Retrieval Settings</TabsTrigger>
        <TabsTrigger value="testing">Testing</TabsTrigger>
      </TabsList>

      <TabsContent value="documents">
        <Card>
          <CardHeader>
            <CardTitle>Knowledge Base Documents</CardTitle>
            <CardDescription>
              Connect and manage documents for this GPT's knowledge base
            </CardDescription>
            <div className="mt-2">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search documents..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <RefreshCw className="h-6 w-6 animate-spin" />
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Document</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {documents
                    .filter(doc => 
                      doc.title.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map(doc => (
                      <TableRow key={doc.id}>
                        <TableCell className="font-medium">{doc.title}</TableCell>
                        <TableCell>{doc.file_type.toUpperCase()}</TableCell>
                        <TableCell>
                          {connectedDocs.includes(doc.id) ? (
                            <span className="flex items-center text-green-600">
                              <Database className="h-4 w-4 mr-1" />
                              Connected
                            </span>
                          ) : (
                            <span className="text-gray-500">Not Connected</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant={connectedDocs.includes(doc.id) ? "destructive" : "default"}
                            size="sm"
                            onClick={() => {
                              if (connectedDocs.includes(doc.id)) {
                                handleDisconnect(doc.id);
                              } else {
                                handleConnect(doc.id);
                              }
                            }}
                          >
                            {connectedDocs.includes(doc.id) ? "Disconnect" : "Connect"}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="settings">
        <Card>
          <CardHeader>
            <CardTitle>Retrieval Configuration</CardTitle>
            <CardDescription>
              Configure how this GPT retrieves and uses document knowledge
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Retrieval Type</Label>
              <Select
                value={settings.retrievalType}
                onValueChange={(value) => setSettings({...settings, retrievalType: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="semantic">Semantic Search</SelectItem>
                  <SelectItem value="keyword">Keyword Search</SelectItem>
                  <SelectItem value="hybrid">Hybrid Search</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Relevance Threshold</Label>
              <Input
                type="number"
                min="0"
                max="1"
                step="0.1"
                value={settings.relevanceThreshold}
                onChange={(e) => setSettings({...settings, relevanceThreshold: parseFloat(e.target.value)})}
              />
              <p className="text-sm text-gray-500">
                Minimum similarity score (0-1) for retrieved content
              </p>
            </div>

            <div className="space-y-2">
              <Label>Maximum Results</Label>
              <Input
                type="number"
                min="1"
                max="10"
                value={settings.maxResults}
                onChange={(e) => setSettings({...settings, maxResults: parseInt(e.target.value)})}
              />
              <p className="text-sm text-gray-500">
                Maximum number of document chunks to retrieve per query
              </p>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="testing">
        <Card>
          <CardHeader>
            <CardTitle>Knowledge Testing</CardTitle>
            <CardDescription>
              Test and validate the GPT's knowledge retrieval capabilities
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Test Query</Label>
              <Input
                placeholder="Enter a test query..."
                className="mb-4"
              />
              <Button
                onClick={testKnowledgeRetrieval}
                disabled={isProcessing}
                className="w-full"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <Network className="mr-2 h-4 w-4" />
                    Test Knowledge Retrieval
                  </>
                )}
              </Button>
            </div>

            <div className="mt-6">
              <h4 className="font-medium mb-2">Knowledge Graph Preview</h4>
              <div className="border rounded-lg p-4 h-[300px] flex items-center justify-center bg-gray-50">
                <p className="text-gray-500">
                  Knowledge graph visualization would be displayed here
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}