import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2, ExternalLink, Share } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import ShareGPTDialog from "./ShareGPTDialog";

const categoryColors = {
  business: "bg-blue-100 text-blue-800",
  creative: "bg-purple-100 text-purple-800",
  technical: "bg-green-100 text-green-800",
  academic: "bg-yellow-100 text-yellow-800",
  personal: "bg-pink-100 text-pink-800"
};

export default function GPTList({ gpts, onEdit, onDelete }) {
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedGpt, setSelectedGpt] = useState(null);

  const handleShare = (gpt) => {
    setSelectedGpt(gpt);
    setShareDialogOpen(true);
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {gpts.map((gpt) => (
          <Card 
            key={gpt.id} 
            className="group relative overflow-hidden border-transparent shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-white/50 to-gray-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            
            <CardHeader className="pb-3 relative">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg font-bold text-gray-900 group-hover:text-indigo-700 transition-colors duration-200">
                    {gpt.name}
                  </CardTitle>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Badge className={`transition-all duration-200 ${categoryColors[gpt.category]}`}>
                      {gpt.category}
                    </Badge>
                    {!gpt.is_active && (
                      <Badge variant="outline" className="text-gray-500">
                        Inactive
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="text-sm relative">
              <CardDescription className="line-clamp-2 text-gray-600 group-hover:text-gray-900 transition-colors duration-200">
                {gpt.description || "No description provided."}
              </CardDescription>
            </CardContent>
            
            <CardFooter className="flex justify-end relative pt-4 border-t">
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="ghost"
                  className="text-indigo-500 hover:text-indigo-700 hover:bg-indigo-50 transition-all duration-200"
                  onClick={() => handleShare(gpt)}
                >
                  <Share className="w-4 h-4" />
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost"
                  className="transition-all duration-200 hover:bg-indigo-50 hover:text-indigo-700"
                  onClick={() => onEdit(gpt)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost"
                  className="text-red-500 hover:text-red-700 hover:bg-red-50 transition-all duration-200"
                  onClick={() => onDelete(gpt)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
                <Link to={createPageUrl("UseGPT", `id=${gpt.id}`)}>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    className="text-blue-500 hover:text-blue-700 hover:bg-blue-50 transition-all duration-200"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Share "{selectedGpt?.name}"</DialogTitle>
          </DialogHeader>
          {selectedGpt && (
            <ShareGPTDialog 
              gpt={selectedGpt} 
              onClose={() => setShareDialogOpen(false)} 
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}