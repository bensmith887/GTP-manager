import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, Copy, Mail } from "lucide-react";
import { GPTShare } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Switch } from "@/components/ui/switch";
import { createPageUrl } from "@/utils";

export default function ShareGPTDialog({ gpt, onClose }) {
  const [shareData, setShareData] = useState({
    recipient_email: "",
    recipient_name: "",
    company: "",
    expiry_date: null,
    notes: ""
  });
  const [shareCode, setShareCode] = useState("");
  const [shareUrl, setShareUrl] = useState("");
  const [isShared, setIsShared] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [sendEmail, setSendEmail] = useState(true);

  const generateShareCode = () => {
    return Math.random().toString(36).substring(2, 10) + 
           Math.random().toString(36).substring(2, 10);
  };

  const handleShare = async () => {
    setIsSending(true);
    try {
      // Generate a unique share code
      const code = generateShareCode();
      
      // Create a share record
      await GPTShare.create({
        gpt_id: gpt.id,
        share_code: code,
        recipient_email: shareData.recipient_email,
        recipient_name: shareData.recipient_name,
        company: shareData.company,
        expiry_date: shareData.expiry_date,
        notes: shareData.notes,
        is_active: true
      });
      
      // Create sharing URL
      const url = window.location.origin + createPageUrl("SharedGPT", `code=${code}`);
      setShareUrl(url);
      setShareCode(code);
      setIsShared(true);
      
      // Send email if selected
      if (sendEmail) {
        await SendEmail({
          to: shareData.recipient_email,
          subject: `Access to "${gpt.name}" GPT`,
          body: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>You've been given access to a custom GPT</h2>
              <p>Hello ${shareData.recipient_name || "there"},</p>
              <p>You've been given access to use the "${gpt.name}" GPT.</p>
              <p><strong>Description:</strong> ${gpt.description || "No description provided."}</p>
              <p>Click the link below to access it:</p>
              <p><a href="${url}" style="display: inline-block; background-color: #4f46e5; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">Access Your GPT</a></p>
              <p>Or copy this link: ${url}</p>
              ${shareData.expiry_date ? `<p><small>Note: Your access expires on ${format(new Date(shareData.expiry_date), 'PPP')}.</small></p>` : ''}
              <p>If you have any questions, please contact the administrator.</p>
            </div>
          `
        });
      }
    } catch (error) {
      console.error("Error sharing GPT:", error);
      alert("Failed to share GPT. Please try again.");
    } finally {
      setIsSending(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copied to clipboard!");
  };

  return (
    <div className="space-y-6">
      {!isShared ? (
        <>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="recipient_email">Recipient Email*</Label>
              <Input
                id="recipient_email"
                value={shareData.recipient_email}
                onChange={(e) => setShareData({...shareData, recipient_email: e.target.value})}
                placeholder="Enter recipient's email"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="recipient_name">Recipient Name</Label>
              <Input
                id="recipient_name"
                value={shareData.recipient_name}
                onChange={(e) => setShareData({...shareData, recipient_name: e.target.value})}
                placeholder="Enter recipient's name"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="company">Company</Label>
              <Input
                id="company"
                value={shareData.company}
                onChange={(e) => setShareData({...shareData, company: e.target.value})}
                placeholder="Enter company name"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Expiry Date (optional)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {shareData.expiry_date ? (
                      format(new Date(shareData.expiry_date), "PPP")
                    ) : (
                      <span>No expiry date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={shareData.expiry_date ? new Date(shareData.expiry_date) : undefined}
                    onSelect={(date) => setShareData({...shareData, expiry_date: date})}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Internal Only)</Label>
              <Textarea
                id="notes"
                value={shareData.notes}
                onChange={(e) => setShareData({...shareData, notes: e.target.value})}
                placeholder="Add any notes about this share"
                className="h-20"
              />
            </div>
            
            <div className="flex items-center space-x-2 pt-2">
              <Switch
                id="send-email"
                checked={sendEmail}
                onCheckedChange={setSendEmail}
              />
              <Label htmlFor="send-email" className="cursor-pointer">
                Send invitation email
              </Label>
            </div>
          </div>
          
          <div className="flex justify-end gap-3">
            <Button
              variant="outline"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button
              className="bg-indigo-600 hover:bg-indigo-700"
              onClick={handleShare}
              disabled={!shareData.recipient_email || isSending}
            >
              {isSending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Sharing...
                </>
              ) : (
                "Share GPT"
              )}
            </Button>
          </div>
        </>
      ) : (
        <div className="space-y-4">
          <div className="rounded-lg bg-green-50 p-4 text-green-800">
            <h3 className="font-medium mb-2">GPT shared successfully!</h3>
            <p className="text-sm">
              Your GPT has been shared with {shareData.recipient_email}.
              {sendEmail && " An invitation email has been sent."}
            </p>
          </div>
          
          <div className="space-y-2">
            <Label>Access Link</Label>
            <div className="flex items-center gap-2">
              <Input
                value={shareUrl}
                readOnly
                className="font-mono text-sm"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => copyToClipboard(shareUrl)}
                className="flex-shrink-0"
                title="Copy link"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500">
              This link will allow {shareData.recipient_name || "the recipient"} to access this GPT.
            </p>
          </div>
          
          <div className="flex justify-end gap-3">
            {!sendEmail && (
              <Button
                variant="outline"
                className="gap-2"
                onClick={async () => {
                  setIsSending(true);
                  try {
                    await SendEmail({
                      to: shareData.recipient_email,
                      subject: `Access to "${gpt.name}" GPT`,
                      body: `
                        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                          <h2>You've been given access to a custom GPT</h2>
                          <p>Hello ${shareData.recipient_name || "there"},</p>
                          <p>You've been given access to use the "${gpt.name}" GPT.</p>
                          <p><strong>Description:</strong> ${gpt.description || "No description provided."}</p>
                          <p>Click the link below to access it:</p>
                          <p><a href="${shareUrl}" style="display: inline-block; background-color: #4f46e5; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">Access Your GPT</a></p>
                          <p>Or copy this link: ${shareUrl}</p>
                          ${shareData.expiry_date ? `<p><small>Note: Your access expires on ${format(new Date(shareData.expiry_date), 'PPP')}.</small></p>` : ''}
                          <p>If you have any questions, please contact the administrator.</p>
                        </div>
                      `
                    });
                    alert("Email sent successfully!");
                  } catch (error) {
                    console.error("Error sending email:", error);
                    alert("Failed to send email. Please try again.");
                  } finally {
                    setIsSending(false);
                  }
                }}
                disabled={isSending}
              >
                {isSending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-600 mr-2" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Mail className="h-4 w-4" />
                    Send Email
                  </>
                )}
              </Button>
            )}
            <Button
              onClick={onClose}
            >
              Close
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}