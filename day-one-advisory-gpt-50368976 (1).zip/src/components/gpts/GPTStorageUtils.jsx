import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { GPT } from "@/api/entities";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UploadFile } from "@/api/integrations";
import { Download, Upload, Trash2, Save, FileText } from "lucide-react";

export function GPTStorageUtils({ refreshGPTs }) {
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [fileInputKey, setFileInputKey] = useState(Date.now());
  const [selectedFile, setSelectedFile] = useState(null);
  const [isImporting, setIsImporting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  const exportToJson = async () => {
    try {
      setIsExporting(true);
      const gpts = await GPT.list();
      
      const dataStr = JSON.stringify(gpts, null, 2);
      const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
      
      const exportFileDefaultName = `gpts-export-${new Date().toISOString().slice(0, 10)}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      alert(`${gpts.length} GPTs exported to JSON file.`);
    } catch (error) {
      alert("Export Failed: " + (error.message || "An error occurred"));
    } finally {
      setIsExporting(false);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const importFromJson = async () => {
    if (!selectedFile) return;
    
    try {
      setIsImporting(true);
      
      const { file_url } = await UploadFile({ file: selectedFile });
      
      const response = await fetch(file_url);
      const importedData = await response.json();
      
      if (!Array.isArray(importedData)) {
        throw new Error("Invalid import file format");
      }
      
      let importedCount = 0;
      
      for (const gptData of importedData) {
        const { id, created_date, updated_date, created_by, ...gptToImport } = gptData;
        
        await GPT.create(gptToImport);
        importedCount++;
      }
      
      alert(`${importedCount} GPTs imported successfully.`);
      
      setSelectedFile(null);
      setFileInputKey(Date.now());
      setImportDialogOpen(false);
      
      refreshGPTs();
      
    } catch (error) {
      alert("Import Failed: " + (error.message || "An error occurred"));
    } finally {
      setIsImporting(false);
    }
  };

  const clearAllGPTs = async () => {
    try {
      setIsClearing(true);
      const gpts = await GPT.list();
      
      for (const gpt of gpts) {
        await GPT.delete(gpt.id);
      }
      
      alert(`All ${gpts.length} GPTs have been deleted.`);
      
      refreshGPTs();
      
    } catch (error) {
      alert("Clear Failed: " + (error.message || "An error occurred"));
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <div className="flex flex-wrap gap-2 mb-2">
      <Button
        variant="outline"
        size="sm"
        className="gap-2"
        onClick={exportToJson}
        disabled={isExporting}
      >
        {isExporting ? (
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-700" />
        ) : (
          <Download className="w-4 h-4" />
        )}
        Export
      </Button>
      
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Upload className="w-4 h-4" />
            Import
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import GPTs</DialogTitle>
            <DialogDescription>
              Upload a JSON file with GPT configurations to import them.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="gpt-file">JSON File</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="gpt-file"
                  type="file"
                  key={fileInputKey}
                  accept=".json"
                  onChange={handleFileChange}
                />
                {selectedFile && (
                  <div className="text-sm text-gray-500 flex items-center">
                    <FileText className="w-4 h-4 mr-1" />
                    {selectedFile.name}
                  </div>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={importFromJson} 
              disabled={!selectedFile || isImporting}
              className="gap-2"
            >
              {isImporting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  Importing...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Import GPTs
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button 
            variant="outline" 
            size="sm" 
            className="gap-2 text-red-600 hover:bg-red-50 hover:text-red-700 border-red-200"
          >
            <Trash2 className="w-4 h-4" />
            Clear All
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete all your
              GPT configurations.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={clearAllGPTs}
              disabled={isClearing}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {isClearing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Clearing...
                </>
              ) : (
                "Delete All GPTs"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}