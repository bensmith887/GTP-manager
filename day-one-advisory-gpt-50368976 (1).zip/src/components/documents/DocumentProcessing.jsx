
import React, { useState, useEffect } from 'react';
import { Document } from '@/api/entities';
import { DocumentChunk } from '@/api/entities';
import { RAGSettings } from '@/api/entities';
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from 'date-fns';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FileText,
  Database,
  Settings,
  Code,
  ChevronRight,
  Zap,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Search,
  Processor
} from 'lucide-react';

export default function DocumentProcessing({ document, onComplete }) {
  const [status, setStatus] = useState('idle');
  const [progress, setProgress] = useState(0);
  const [processingLogs, setProcessingLogs] = useState([]);
  const [processingStats, setProcessingStats] = useState({
    totalChunks: 0,
    processedChunks: 0,
    failedChunks: 0,
    averageChunkSize: 0
  });

  const [settings, setSettings] = useState({
    embeddingModel: 'openai-ada-002',
    chunkSize: 1000,
    chunkOverlap: 200,
    vectorDb: 'internal',
    searchType: 'hybrid',
    topK: 5,
    similarityThreshold: 0.7,
    enableCitations: true,
    parallelProcessing: true,
    preserveStructure: true
  });

  const addLog = (message, type = 'info') => {
    setProcessingLogs(prev => [...prev, { message, type, timestamp: new Date() }]);
  };

  const updateProgress = (value) => {
    setProgress(value);
    if (value === 100) {
      setStatus('success');
    }
  };

  const startProcessing = async () => {
    setStatus('processing');
    setProgress(0);
    setProcessingLogs([]);
    
    try {
      // Phase 1: Document Parsing
      addLog('Starting document parsing...', 'info');
      await simulateProcessing(20, 'Parsing document structure');
      
      // Phase 2: Content Extraction
      addLog('Extracting content...', 'info');
      await simulateProcessing(40, 'Extracting text and metadata');
      
      // Phase 3: Chunking
      addLog('Creating semantic chunks...', 'info');
      await simulateProcessing(60, 'Applying intelligent chunking');
      
      // Phase 4: Embedding Generation
      addLog('Generating embeddings...', 'info');
      await simulateProcessing(80, 'Processing with ' + settings.embeddingModel);
      
      // Phase 5: Vector Storage
      addLog('Storing in vector database...', 'info');
      await simulateProcessing(100, 'Finalizing storage');
      
      addLog('Processing completed successfully!', 'success');
      if (onComplete) onComplete();
      
    } catch (error) {
      setStatus('error');
      addLog('Error during processing: ' + error.message, 'error');
    }
  };

  const simulateProcessing = async (targetProgress, operation) => {
    const start = progress;
    const increment = (targetProgress - start) / 5;
    
    for (let i = 0; i < 5; i++) {
      await new Promise(resolve => setTimeout(resolve, 500));
      updateProgress(Math.min(start + (increment * (i + 1)), targetProgress));
      setProcessingStats(prev => ({
        ...prev,
        processedChunks: prev.processedChunks + 1,
        totalChunks: prev.totalChunks + (i === 0 ? 5 : 0)
      }));
    }
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="processing" className="w-full">
        <TabsList>
          <TabsTrigger value="processing">Processing</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="processing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Processor className="h-5 w-5" />
                Processing Status
              </CardTitle>
              <CardDescription>
                Document processing and embedding generation progress
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{status === 'idle' ? 'Ready to process' : status === 'processing' ? 'Processing...' : status === 'success' ? 'Completed' : 'Error'}</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="space-y-1">
                  <Label>Total Chunks</Label>
                  <div className="text-2xl font-bold">{processingStats.totalChunks}</div>
                </div>
                <div className="space-y-1">
                  <Label>Processed</Label>
                  <div className="text-2xl font-bold">{processingStats.processedChunks}</div>
                </div>
              </div>

              <Button
                className="w-full mt-4"
                onClick={startProcessing}
                disabled={status === 'processing'}
              >
                {status === 'processing' ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-4 w-4" />
                    Start Processing
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Processing Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Embedding Model</Label>
                <Select
                  value={settings.embeddingModel}
                  onValueChange={(value) => setSettings({...settings, embeddingModel: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="openai-ada-002">OpenAI Ada 002</SelectItem>
                    <SelectItem value="sbert-mpnet-base">SBERT MPNet Base</SelectItem>
                    <SelectItem value="miniLM-L6">MiniLM L6</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Chunk Size (tokens)</Label>
                <Slider
                  value={[settings.chunkSize]}
                  min={100}
                  max={2000}
                  step={100}
                  onValueChange={([value]) => setSettings({...settings, chunkSize: value})}
                />
                <div className="text-sm text-gray-500">{settings.chunkSize} tokens</div>
              </div>

              <div className="space-y-2">
                <Label>Vector Database</Label>
                <Select
                  value={settings.vectorDb}
                  onValueChange={(value) => setSettings({...settings, vectorDb: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="internal">Internal DB</SelectItem>
                    <SelectItem value="pinecone">Pinecone</SelectItem>
                    <SelectItem value="weaviate">Weaviate</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Parallel Processing</Label>
                <Switch
                  checked={settings.parallelProcessing}
                  onCheckedChange={(checked) => setSettings({...settings, parallelProcessing: checked})}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Preserve Document Structure</Label>
                <Switch
                  checked={settings.preserveStructure}
                  onCheckedChange={(checked) => setSettings({...settings, preserveStructure: checked})}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Processing Logs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] rounded-md border p-4">
                {processingLogs.map((log, index) => (
                  <div
                    key={index}
                    className={`flex items-start gap-2 mb-2 text-sm ${
                      log.type === 'error' ? 'text-red-600' :
                      log.type === 'success' ? 'text-green-600' :
                      'text-gray-600'
                    }`}
                  >
                    <span className="text-gray-400 min-w-[60px]">
                      {format(log.timestamp, 'HH:mm:ss')}
                    </span>
                    {log.type === 'error' && <AlertCircle className="h-4 w-4" />}
                    {log.type === 'success' && <CheckCircle className="h-4 w-4" />}
                    {log.type === 'info' && <ChevronRight className="h-4 w-4" />}
                    <span>{log.message}</span>
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
