import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { cn } from "@/lib/utils";
import { MessagesSquare, Settings2, Command, UserPlus, Users } from "lucide-react";
import { User } from "@/api/entities";

export default function Header() {
  const location = useLocation();
  const currentPath = location.pathname;
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    checkUserRole();
  }, []);

  const checkUserRole = async () => {
    try {
      const user = await User.me();
      setIsAdmin(user.role === 'admin');
    } catch (error) {
      console.error("Error checking user role:", error);
    }
  };

  const navigation = [
    {
      name: "Use GPTs",
      href: createPageUrl("UseGPT"),
      icon: MessagesSquare,
      match: /\/UseGPT/
    },
    {
      name: "Manage GPTs",
      href: createPageUrl("ManageGPTs"),
      icon: Settings2,
      match: /\/ManageGPTs/,
      adminOnly: true
    },
    {
      name: "GPT Shares",
      href: createPageUrl("ManageShares"),
      icon: UserPlus,
      match: /\/ManageShares/,
      adminOnly: true
    },
    {
      name: "User Access",
      href: createPageUrl("ManageUserAccess"),
      icon: Users,
      match: /\/ManageUserAccess/,
      adminOnly: true
    }
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto px-4 flex h-16 items-center justify-between">
        <Link 
          to={createPageUrl("UseGPT")} 
          className="flex items-center gap-2 mr-4 group transition-colors"
        >
          <Command className="w-6 h-6 text-indigo-600 group-hover:text-indigo-700 transition-colors" />
          <span className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-indigo-500 bg-clip-text text-transparent">
            GPT Manager
          </span>
        </Link>

        <nav className="flex items-center gap-1 md:gap-2 overflow-x-auto">
          {navigation
            .filter(item => !item.adminOnly || isAdmin)
            .map((item) => {
              const isActive = item.match.test(currentPath);
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={cn(
                    "group inline-flex h-9 w-max items-center justify-center rounded-md px-2 md:px-4 py-2 text-sm font-medium transition-all duration-200 hover:bg-gray-100 hover:text-gray-900 focus:bg-gray-100 focus:text-gray-900 focus:outline-none disabled:pointer-events-none disabled:opacity-50",
                    isActive 
                      ? "bg-indigo-50 text-indigo-900 shadow-sm" 
                      : "text-gray-600 hover:shadow-sm"
                  )}
                >
                  <item.icon className={cn(
                    "mr-1 md:mr-2 h-4 w-4 transition-colors duration-200",
                    isActive 
                      ? "text-indigo-600" 
                      : "text-gray-400 group-hover:text-indigo-500"
                  )} />
                  <span className="hidden sm:inline">{item.name}</span>
                </Link>
              );
            })}
        </nav>
      </div>
    </header>
  );
}