import * as React from "react";
import { cn } from "@/lib/utils";

// Simple tooltip component without radix-ui dependency
function Tooltip({ children, content, className }) {
  const [isVisible, setIsVisible] = React.useState(false);
  const [position, setPosition] = React.useState({ top: 0, left: 0 });
  const triggerRef = React.useRef(null);

  const showTooltip = (e) => {
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setPosition({
        top: rect.bottom + window.scrollY + 10,
        left: rect.left + window.scrollX + rect.width / 2
      });
      setIsVisible(true);
    }
  };

  const hideTooltip = () => {
    setIsVisible(false);
  };

  return (
    <div className="relative inline-block">
      <div 
        ref={triggerRef}
        onMouseEnter={showTooltip} 
        onMouseLeave={hideTooltip}
        onFocus={showTooltip}
        onBlur={hideTooltip}
      >
        {children}
      </div>
      {isVisible && (
        <div
          className={cn(
            "absolute z-50 p-2 text-sm bg-white border rounded shadow-md max-w-xs text-gray-800",
            className
          )}
          style={{
            top: `${position.top}px`,
            left: `${position.left}px`,
            transform: 'translateX(-50%)'
          }}
        >
          {content}
        </div>
      )}
    </div>
  );
}

// Simplified versions of Radix UI components
const TooltipProvider = ({ children }) => children;
const TooltipTrigger = ({ asChild, children }) => children;
const TooltipContent = React.forwardRef(({ children, className, ...props }, ref) => (
  <div ref={ref} className={cn("p-2 text-sm", className)} {...props}>
    {children}
  </div>
));
TooltipContent.displayName = "TooltipContent";

export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };
export default Tooltip;