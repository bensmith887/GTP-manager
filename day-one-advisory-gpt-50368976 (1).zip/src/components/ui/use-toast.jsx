import React from "react";

// Simple toast function for notifications
function toast({ title, description, variant }) {
  const toastId = Math.random().toString(36).substring(2, 9);
  
  // Create toast element
  const toastElement = document.createElement("div");
  toastElement.id = `toast-${toastId}`;
  toastElement.className = `fixed bottom-4 right-4 z-50 max-w-md p-4 rounded-lg shadow-lg ${
    variant === "destructive" ? "bg-red-100 text-red-800 border border-red-200" : "bg-white text-gray-800 border border-gray-200"
  }`;
  
  // Create title
  if (title) {
    const titleEl = document.createElement("div");
    titleEl.className = "font-semibold";
    titleEl.textContent = title;
    toastElement.appendChild(titleEl);
  }
  
  // Create description
  if (description) {
    const descEl = document.createElement("div");
    descEl.className = "text-sm mt-1";
    descEl.textContent = description;
    toastElement.appendChild(descEl);
  }
  
  // Append to body
  document.body.appendChild(toastElement);
  
  // Remove after timeout
  setTimeout(() => {
    if (document.body.contains(toastElement)) {
      toastElement.classList.add("opacity-0", "transition-opacity");
      setTimeout(() => {
        if (document.body.contains(toastElement)) {
          document.body.removeChild(toastElement);
        }
      }, 300);
    }
  }, 3000);
  
  return {
    id: toastId,
    dismiss: () => {
      if (document.body.contains(toastElement)) {
        document.body.removeChild(toastElement);
      }
    }
  };
}

// Hook to use toast
function useToast() {
  return { toast };
}

export { useToast, toast };
export default useToast;